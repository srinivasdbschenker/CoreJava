class ArithmaticDemo{

public static void main(String[] args){

int a=10;
int b=20;

System.out.println("the sum "+(a+b));
System.out.println("the subtraction"+(a-b));
System.out.println("the multiplication"+(a*b));
System.out.println("the division"+(a/b));
System.out.println("modulus operation"+(a%b));

System.out.println("---------------------------");
System.out.println("the unary minus "+(-a));
System.out.println("the increment operator"+(++a));
System.out.println("the decrement operator"+(--b));

System.out.println("the increment operator"+(a++));
System.out.println("the decrement operator"+(b--));

System.out.println("-----------------------");

int c=5;  // 101+1   110
System.out.println("bitwise complemetn of "+c+" complement is "+(~c));

int x=10;   //  0000 1010
int y=11;  //   0000 1011
          // --------------------&
          //     0000 1010 
          //     0000 1011
//^             0000  0001     

 System.out.println("x&y "+(x&y));


System.out.println("x|y "+(x|y));

 System.out.println("x^y "+(x^y));

// 10          0000 1010
//<<2        0010 1000
//>>2            0000 10     
 System.out.println("x<<2 "+(x<<2));
 System.out.println("x>>2:: "+(x>>2));

 System.out.println("x>>>2:: "+(x>>>2));


 System.out.println("x>b?a:b ==> "+((x>b)?a:b));

System.out.println("x<b?a:b ==> "+((x<b)?a:b));
System.out.println("x<=b?a:b ==> "+((x<=b)?a:b));
System.out.println("x>=b?a:b ==> "+((x>=b)?a:b));

}

}