class DataType{

public static void main(String[] args){

int x;
x=25;
int y=34;

System.out.println("x values"+x+" y value is "+y);

float z=3.1;
System.out.println("z value "+ z);
double p=3.123456789;
System.out.println("p value is"+p);

char c='1';
String s="raja123";
System.out.println("character value "+c);
System.out.println("s value is "+ s);
String r="rani";
System.out.println("r value si "+ r);

boolean f=true;
System.out.println("f value is "+f);

}

}