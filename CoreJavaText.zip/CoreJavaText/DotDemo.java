public class DotDemo{

public static void main(String[] args){

DotEx de=new DotEx();

de.a=20;
de.b=30;
de.c='a';

System.out.println("a value is "+de.a);
System.out.println("b value is "+ de.b);
System.out.println("c values is "+de.c);

}

}