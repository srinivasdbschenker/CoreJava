public class DotEx{

public int a;
public float b;
public char c;
}