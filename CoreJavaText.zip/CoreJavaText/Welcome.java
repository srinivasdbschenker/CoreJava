//import java.lang.System;
class Welcome{
 

public static void main(String[] args){//jre  jvm

System.out.println("Welcome to java");//print statement
System.out.print("Welcome to java");

System.out.println("Welcome to java");
System.out.println("Welcome to java");
System.out.println("\nWelcome to java");
System.out.println("Welcome to java");

System.out.print("Welcome to java\n");
System.out.println("Welcome to java\n\n");

System.out.println(" Welcome to  java");
System.out.println("\t Welcome to java");

System.out.println("\"Welcome to java");
System.out.println("\\Welcome to java");
System.out.println("\'Welcome to java");





  
 Welcome w=new Welcome();
 Welcome w1=new Welcome();
 
}
}