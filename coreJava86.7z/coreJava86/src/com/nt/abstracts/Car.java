package com.nt.abstracts;

public abstract class Car {
	
	int regno;
	
	Car(int r){
		regno =r;
	}
	
	void openTank(){
		System.out.println("fill the tank");
	}
	
	abstract void steering(int direction, int angle);
	abstract void braking(int force);
	
	

}
