package com.nt.abstracts;

public class Common {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sub1 obj1=new Sub1();
		Sub2 obj2=new Sub2();
		Sub3 obj3=new Sub3();
		
		obj1.calculate(4);
		obj2.calculate(25);
		obj3.calculate(3);
		
		obj1.cal(3);
		

	}

}
