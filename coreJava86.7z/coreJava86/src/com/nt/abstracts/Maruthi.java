package com.nt.abstracts;

public class Maruthi  extends Car{
	
	Maruthi(int regno){
		super(regno);
	}

	@Override
	void steering(int direction, int angle) {
		// TODO Auto-generated method stub
		System.out.println("take a turn");
		System.out.println("this is ordinary steering");
	}

	@Override
	void braking(int force) {
		// TODO Auto-generated method stub
		System.out.println("brakes applied");
		System.out.println("These are hydrauli brakes");
	}

}
