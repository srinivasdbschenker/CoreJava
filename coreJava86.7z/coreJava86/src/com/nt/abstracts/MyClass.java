package com.nt.abstracts;

abstract class MyClass {
	
	void cal(double x){
		System.out.println("square :: "+(x*x));
	}
	
	abstract void calculate(double x);
	

}
