package com.nt.abstracts;

public class Santro extends Car{

	Santro(int regno) {
		super(regno);
		// TODO Auto-generated constructor stub
	}

	@Override
	void steering(int direction, int angle) {
		// TODO Auto-generated method stub
		
		System.out.println("take turn");
		System.out.println("this car uses power steering");
		
	}

	@Override
	void braking(int force) {
		// TODO Auto-generated method stub
		
		System.out.println("brakes applied");
		System.out.println("this cares uses gas brakes");
	}

}
