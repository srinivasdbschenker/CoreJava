package com.nt.abstracts;

public class Sub1 extends MyClass {

	@Override
	void calculate(double x) {
		// TODO Auto-generated method stub
		System.out.println("square :: "+(x*x));
		
	}

}
