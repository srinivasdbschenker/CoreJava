package com.nt.abstracts;

public class Sub2 extends MyClass {

	@Override
	void calculate(double x) {
		// TODO Auto-generated method stub
		
		System.out.println("squrare root :: "+Math.sqrt(2));
		
	}

}
