package com.nt.abstracts;

public class UseCar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Maruthi m=new Maruthi(1001);
		Santro s=new Santro(50005);
		Car ref;
		
		m.openTank();
	
		
		ref=m;// to use santor car ref=s;
		
		
		ref.openTank();
		ref.steering(1,90);
		ref.braking(500);
		
		ref=s;
		ref.openTank();
		ref.braking(200);
		ref.steering(1, 45);

	}

}
