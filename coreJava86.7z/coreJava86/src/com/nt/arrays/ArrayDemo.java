package com.nt.arrays;

import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int[] a={100,25,24,26,28,29};

	System.out.println(a[0]);

	System.out.println(a[1]);
	System.out.println(a[2]);
	System.out.println(a[3]);
	System.out.println(a[4]);
	System.out.println(a[5]);
	
	System.out.println("-----------------");
	
	for(int i=0;i<6;i++){
		System.out.println("a["+i+"]-->"+a[i]+"addrs:: "+a.hashCode());
		
		
	}
	
	System.out.println("-------------------------");
	Scanner sc=new Scanner(System.in);
	int[] b=new int[10];
	for(int i=0; i<10; i++){
		System.out.println("enter array value"+i);
		b[i]=sc.nextInt();
	}
	
	for(int i=0;i<b.length; i++){
		System.out.println("b["+i+"]-->"+b[i]+"  adress"+b.hashCode());
	}
	
	}

}
