package com.nt.arrays;

import java.util.Scanner;

public class D3array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][][] a=new int[3][2][3];
		Scanner sc=new Scanner(System.in);

		
		for(int i=0;i<3;i++){
			for(int j=0;j<2;j++){
				for(int k=0; k<3; k++){
				 System.out.println("enter value");
				 a[i][j][k]=sc.nextInt();
				}
				}
			}
		

		for(int i=0;i<3;i++){
			for(int j=0;j<2;j++){
				for(int k=0; k<3; k++){
					System.out.print("a["+i+"]["+j+"]["+k+"]  "+a[i][j][k]+ "    ");
				}
				System.out.println();
			}
			System.out.println("------------------");
		}
		

	}

}
