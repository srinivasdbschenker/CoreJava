package com.nt.arrays;

import java.util.Scanner;

public class DifferentDataTypeArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// float char string 
		
		float salary[]={567.1f, 12000f, 4500.35f, 2000.34f, 9050f, 102.3f};
		char ch[]={'a','b','c','d','e','f'};// inputMismatch Exception
		String names[]={"raja","rani","rao","surya","vikram","vijay"};
		
		float sal[]=new float[10];// max 10--> 11th it will arrayindexoutofbound exception
		String name[]=new String[10]; //String[] sal=new String[5];
		
		char[] c=new char[10];
		
		Scanner sc=new Scanner(System.in);
		
for(int i=0;i<5;i++){
	System.out.println("enter float value to sal");
	sal[i]=sc.nextFloat();
	System.out.println("enter name string");
	name[i]=sc.next();
	System.out.println("enter char value");
	c[i]=sc.next().charAt(0);
}

for(int i=0; i<6;i++){
	System.out.println("ch["+i+"]-->"+ch[i]+" | names["+i+"]-> "+names[i]+"| salary["+i+"]-->"+salary[i]);
}

for(int i=0;i<11;i++){
	System.out.println("sal["+i+"]-->"+sal[i]+" | name["+i+"]-->"+name[i]+" | c["+i+"]-->"+c[i]);
}


	}

}
