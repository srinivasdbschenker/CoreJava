package com.nt.basics;

public class DotEX {
	int a;
	float b;
	char c;
	DotEX()
	{
		
	}
}
