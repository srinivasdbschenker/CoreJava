package com.nt.collectionss;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// newcapacity =(current capacity*3/2)+1;
		
		//10  11-->10*3/2+1; 16
		ArrayList a=new ArrayList();
		a.add(null);
		
		System.out.println();
		a.add("Raja");
		a.add(new Integer(10));
		
		a.add("rani");
		System.out.println(a);
		System.out.println(a.size());
		
		a.add("Raja");
		System.out.println(a);
		a.remove(3);
		System.out.println(a);
		a.add(2, "sonia");
		System.out.println(a);
		a.add(null);
		System.out.println(a);
		a.add(null);
		System.out.println(a);

	}

}
