package com.nt.collectionss;

import java.util.HashMap;
import java.util.Hashtable;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap hm=new HashMap();
		
hm.put("ajay",50);
hm.put("sachin", 77);
hm.put("dhoni", 44);
hm.put("kapil", 60);
hm.put("kholi", 88);
hm.put("sachin", 778);
hm.put(null, null);
hm.put(null, 50);
hm.put("sa", null);


System.out.println(hm);
System.out.println("HM -----------vs-----------HT");
Hashtable ht=new Hashtable();

ht.put("ajay",50);
ht.put("sachin", 77);
ht.put("dhoni", 44);
ht.put("kapil", 60);
ht.put("kholi", 88);
ht.put("sachin", 778);
//ht.put(null, null);
//ht.put(null, 50);
//ht.put("sa", null);


System.out.println(ht);


	}

}
