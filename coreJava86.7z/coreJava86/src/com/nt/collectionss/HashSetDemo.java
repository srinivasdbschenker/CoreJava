package com.nt.collectionss;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet hs=new HashSet();
		hs.add(null);
		hs.add("india");
		hs.add("usa");
		hs.add("japan");
		hs.add("china");
		//hs.add("usa");
		hs.add("zimbaboy");
		hs.add("jermany");
		hs.add(null);
		hs.contains("raja");
		hs.add(11);
		
		System.out.println(hs);
		
		LinkedHashSet l=new LinkedHashSet();
		l.add("india");
		l.add("usa");
		l.add("japan");
		l.add("china");
		l.add("zimbaboy");
		l.add("germany");
		System.out.println(l);
		
		System.out.println("------------------------");
		
		SortedSet s=new TreeSet();
		
		s.add(100);
		s.add(90);
		s.add(160);
		s.add(140);
		
		System.out.println(s);
		
		TreeSet t=new TreeSet();
		t.add("zimbzby");
		t.add("america");
		t.add("london");
		t.add("canada");
		t.add("washigton");
		System.out.println(t);
		
		

	}

}
