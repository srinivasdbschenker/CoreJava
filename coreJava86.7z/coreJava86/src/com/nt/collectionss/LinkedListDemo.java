package com.nt.collectionss;

import java.util.LinkedList;
import java.util.Vector;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList l=new LinkedList();
		
		l.add("raja");
		l.add(new Integer(10));
		l.add(null);
		l.add("raja");
		System.out.println(l);
		
		l.set(0, "rani");
		System.out.println(l);
		l.set(0, "sonia");

		System.out.println("------------------------");
		System.out.println(l);
		
		Vector v=new Vector();
		
		System.out.println(" capacity"+v.capacity());
		
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		v.add("raja");
		System.out.println(v+" capacity "+v.capacity());
		v.add("rani");
		System.out.println(v+" capacity "+v.capacity());
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		v.add("rani");
		System.out.println(v+" capacity "+v.capacity());
		
		v.add("rani");
		System.out.println(v+" capacity "+v.capacity());
		
		
		
	}

}
