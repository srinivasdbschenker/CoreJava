package com.nt.collectionss;

import java.util.LinkedList;

public class Linkelistdemogenric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
LinkedList<String> l=new LinkedList<>();
		
		l.add("raja");
		//l.add(new Integer(10));
		l.add(null);
		l.add("raja");
		System.out.println(l);
		
		
		LinkedList<Double> l1=new LinkedList<>();
		
l1.add(11.2);
l1.add(23.9);
System.out.println(l1);

Thread t=Thread.currentThread();
System.out.println(t);
	}

}
