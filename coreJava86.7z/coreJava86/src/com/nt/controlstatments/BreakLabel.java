package com.nt.controlstatments;

public class BreakLabel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean x=true;
		bl1:{
			bl2:{ System.out.println("block2 started");
			   bl3:{
			       System.out.println("Block3");
			        if(x) break bl2;// goto bl2
			        System.out.println("block3 end");
		           }//end of bl3 
		           System.out.println("block2 end");
		        }//end of bl2
		   System.out.println("block1 end");
		}//end of bl2 
System.out.println("out of all blocks");
	}

}
