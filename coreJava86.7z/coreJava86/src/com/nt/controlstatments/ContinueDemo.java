package com.nt.controlstatments;

public class ContinueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=10; i>=1; i--){
			if(i>5) continue;
			System.out.print(i+"  ");
		}
	}

}
