package com.nt.controlstatments;

public class ContinueLable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int i=1,j;
		lp1: while(i<=3){
			      System.out.println(i);
			      lp2: for(j=1;j<=5;j++){
			    	 
				       System.out.println("\t"+j);
				       i++; 
				       continue lp1;
			   }
			 i++;
			 
			 System.out.println("------------------------");
		}
	}

}
