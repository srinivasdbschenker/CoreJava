package com.nt.controlstatments;

public class DoWhileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x;
		 x=1;
		 do{
			 System.out.println(x);  //1 2 3
			 x++; // x=x+1; //2 3  4
		 }while(x<=10);  //2<=10 t 3<=10 t 
		 
		 System.out.println("--------------------------------------");
		 int y=1;  //y=10
		 while(y<=10){ // y>=1
			 System.out.println(y);
			 y++;  //y--
		 }
		 
		 System.out.println("-----------------------------------------");
		 for(int z=1; z<=10; z++){// z=10 ; x>=1; z--
			 System.out.println(z);
		 }
		 System.out.println("=====================");
		 int r=5;
		 for(int i=1; i<=r;i++){
			 for(int j=1; j<=i; j++){
				 System.out.print("*");
			 }
			 System.out.println();
		 }
		 
		 int arr[]={200,19,56,4, 8};
		 
		 for(int i: arr){
			 System.out.print(i+"  ");
		 }
		 
	}

}
