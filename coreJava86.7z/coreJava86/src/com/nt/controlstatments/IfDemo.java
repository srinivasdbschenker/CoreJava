package com.nt.controlstatments;

public class IfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int n=-5;
		
		if(n==0)
			 System.out.println(n+" -->it is zerro");
		  else if(n>0)
			System.out.println(n+"-->n is positive");
		else
			System.out.println(n+"-->n is negative");

	}

}
