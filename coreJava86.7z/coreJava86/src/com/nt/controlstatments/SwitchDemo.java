package com.nt.controlstatments;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char color='g';
		
		switch(color){
		case 'r': System.out.println("REd");
		              break;
		case 'g':System.out.println("Green");
		        break;
		case 'b':System.out.println("Blue");
		      break;
		      
		case 'w':System.out.println("white");
		break;
		default: System.out.println("nO color");
		}

	}

}
