package com.nt.exceptions;

public class A {
	
	void mehtod1(){
		try{
			
			String str="Hello";
			char ch=str.charAt(5);
			
		}catch(StringIndexOutOfBoundsException sie){
			System.out.println("Please see the index is withing the range");
			throw sie;
		}
	}

}
