package com.nt.exceptions;

public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a=new A();
	 
		try{
		a.mehtod1();
		}catch(StringIndexOutOfBoundsException sie){
			System.out.println("I caught rethrown exception");
		}
	}

}
