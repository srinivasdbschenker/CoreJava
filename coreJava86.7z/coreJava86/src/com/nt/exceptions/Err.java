package com.nt.exceptions;

import java.io.IOException;

public class Err {

	/*
	 * compile time error : syntactical errors found in the code due to which
	 * a program fail to compile
	 * 
	 * 
	 * Run time error: represent ineffieciency of the computer system to execute
	 * particular statement 
	 * 
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("hi how r you");
		System.out.println("wel come to java");

		int x,y,z=0;
		x=100;
		y=0;
		try{
			System.out.println("hi how r you");
			System.out.println("wel come to java");
	
			
		z=x/y;
		System.out.println("z value :: "+z);
		
		System.out.println("hi how r you");
		System.out.println("wel come to java");

		}catch(ArrayIndexOutOfBoundsException aie){
			aie.printStackTrace();
		}
		
		System.out.println("z value :: "+z);
		System.out.println("z value :: "+z);
	
		System.out.println("z value :: "+z);
		
		System.out.println("z value :: "+z);
		System.out.println("z value :: "+z);
		
	}

}
