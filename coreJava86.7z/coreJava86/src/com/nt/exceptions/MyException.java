package com.nt.exceptions;

public class MyException extends Exception{

	private static int accno[]={101,102,103,104,105};
	
	private static String name[]={"raja rao","ramarao","suba rao","bush rao","trump rao"};
	
	private static double bal[]={10000,12000,130,14000,3200};
	
	
	MyException(){
		
	}
	MyException(String str){
		super(str);
		
	}
	
	public static void main(String[] args){
		
		try{
			System.out.println("accno"+"\t"+"customer"+"\t"+"balance");
			
			for(int i=0; i<5;i++){
				System.out.println(accno[i]+"\t"+name[i]+"\t"+bal[i]);
				
				if(bal[i]<1000){
					MyException me=new MyException("balance amount is less");
					
					throw me;
				}
			}
			
		}catch(MyException me){
		me.printStackTrace();
			
		}
		System.out.println("---------------------");
		for(int i=0; i<5;i++){
			System.out.println(accno[i]+"\t"+name[i]+"\t"+bal[i]);
		}
		
	}
	
	
}
