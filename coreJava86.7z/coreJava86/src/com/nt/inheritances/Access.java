package com.nt.inheritances;

public class Access {
protected int a;
protected int b;

}
