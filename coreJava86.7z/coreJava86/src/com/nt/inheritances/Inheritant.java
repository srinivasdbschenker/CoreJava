package com.nt.inheritances;

public class Inheritant {

	/*
	 * 
	 * 1. single inheritance
	 * 
	 * department--> employee
	 * 
	 * birdc--|--> peacock
	 *         --> parrot
	 *          --> sparrow
	 *          producing sub classes from a single super class is called single 
	 *          inheritance
	 * 
	 * 2.multiple ihneritancce:
	 * producing sub classes from multiple super classes is called  multiple 
	 * inheritance
	 * 
	 *       child1         child2
	 *       
	 *       
	 *       
	 *       milk  sugar  teapoweder
	 *        -------------------
	 *                tea
	 *                
	 * why multiple inheriance is not avialble in java?
	 * muliptle inheritance is not avaialable in java 
	 * 1. it leads to confusion for a java program
	 * 2. the progrmmer can achive multiple inheritance by using interfaces
	 * 3. the programmer can achieve mulitple inheritnace by repeatedly uisng 
	 * single inheritance
	 *                
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Square s=new Square(5.5);
		s.area();
		
		Reactangle r=new Reactangle(5,6);
		r.area();
	}

}
