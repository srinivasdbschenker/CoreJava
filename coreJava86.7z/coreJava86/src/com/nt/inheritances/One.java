package com.nt.inheritances;

public class One {

	int i=10;
	One(){
		System.out.println("one constructor");
	}

	One(int i){
		this.i=i;
		
		System.out.println(" super i:: "+i);
	}
	
	void show(){
		System.out.println("super calss method i:: "+i);
	}
}
