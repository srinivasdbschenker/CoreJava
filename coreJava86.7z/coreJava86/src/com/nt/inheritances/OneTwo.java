package com.nt.inheritances;

public class OneTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Two t=new Two();
		t.show();
		
		One o=new One();
		o.show();
		
		Two t1=new Two(11,22);
	

	}

}
