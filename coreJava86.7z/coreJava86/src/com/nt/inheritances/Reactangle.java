package com.nt.inheritances;

public class Reactangle extends Square {

	private double b;
	
	Reactangle(double l, double y) {
		super(l);
		// TODO Auto-generated constructor stub
		b=y;
		
	}
	void area(){
		System.out.println("area of reactangel :: "+(l*b));
	}

}
