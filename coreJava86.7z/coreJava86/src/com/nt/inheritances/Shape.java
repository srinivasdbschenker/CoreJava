package com.nt.inheritances;

public class Shape {

	
	protected double l;
	
	Shape(double l){
		this.l=l;
		
	}
}
