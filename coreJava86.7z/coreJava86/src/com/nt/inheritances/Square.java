package com.nt.inheritances;

public class Square  extends Shape{
	
	Square(double l){
		super(l);
	}
	
	void area(){
		System.out.println("area of square :: "+(l*l));
	}

}
