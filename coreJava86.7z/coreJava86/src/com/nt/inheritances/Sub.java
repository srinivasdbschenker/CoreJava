package com.nt.inheritances;

public class Sub extends Access {
	
	public void get(){
		System.out.println(a);
		System.out.println(b);
	}

}
