package com.nt.inheritances;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sub s=new Sub();
	 s.get();
	 
	 
	}

}
