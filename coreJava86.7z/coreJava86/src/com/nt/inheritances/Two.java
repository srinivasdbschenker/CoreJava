package com.nt.inheritances;

public class Two extends One {


	int i=20;
	Two(){
		System.out.println("two construcotr");
	}
		
	Two(int a, int b){
		//super(a);
		i=b;
		
		System.out.println("i : :"+i);
		System.out.println("b:: "+b);
		System.out.println("a:: "+a );
	}
	void show(){
		System.out.println("sub class method ;; I :: "+i);
		System.out.println("sub class itself super i value:: "+super.i);
		
		int j=i*super.i;
		System.out.println("j "+j);
	}
}
