package com.nt.inheritances;

public class Use {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s=new Student();
		s.setId(101);
		s.setName("raja");
		s.setAddress("hyd");
		s.setMarks(500);
		
		
		System.out.println("id:: "+s.getId());
		System.out.println("name:: "+s.getName());
		System.out.println("address:: "+s.getAddress());
		System.out.println("marks:: "+s.getMarks());
		
		Teacher t=new Teacher();
		t.setId(102);
		t.setName("rani");
		t.setAddress("vizaq");
		t.setSal(2000);
		
		System.out.println("id:: "+t.getId());
		System.out.println("name:: "+t.getName());
		System.out.println("address:: "+t.getAddress());
		System.out.println("sal:: "+t.getSal());
		
		

	}

}
