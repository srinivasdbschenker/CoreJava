package com.nt.interfaces;

public interface InterfaceDemo {
	
	void connect();
	void disconnect();
	

}
