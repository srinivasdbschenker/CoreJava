package com.nt.interfaces;

public interface MyInter {

	void sum();
	void sub();
}
