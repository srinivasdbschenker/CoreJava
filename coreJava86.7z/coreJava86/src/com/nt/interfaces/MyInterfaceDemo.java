package com.nt.interfaces;

public class MyInterfaceDemo {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub

		
		Class c=Class.forName(args[0]);
		
		InterfaceDemo id=(InterfaceDemo) c.newInstance();
		
		id.connect();
		id.disconnect();
	}

}
