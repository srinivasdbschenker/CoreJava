package com.nt.interfaces;

public class OracleDB implements InterfaceDemo {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("connecting to oracle database");
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("disconnected to oracle data base");
		
	}

	
}
