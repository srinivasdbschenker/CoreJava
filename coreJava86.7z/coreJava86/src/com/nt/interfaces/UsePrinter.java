package com.nt.interfaces;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class UsePrinter {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub
		
		/*FileReader fr=new FileReader("config.txt");
		LineNumberReader lnr=new LineNumberReader(fr);
		
		String printername=lnr.readLine();
		*/
		Class c=Class.forName("com.nt.interfaces.IBMPrinter");
		
		
		Printer ref=(Printer) c.newInstance();
		
		ref.printit("Hello , this is printed on the printer");
		ref.disonnect();
		
		
		
		

	}

}
