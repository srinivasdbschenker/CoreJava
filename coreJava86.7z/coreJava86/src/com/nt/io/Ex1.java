package com.nt.io;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=10,s2=20, s3=20,s4=32,s5=23;
		
		
		String s1="Hello";
		int n=65;
		float f=15.12345f;
		System.out.printf("\n\nstring value= %s %n num= %d %n hexadeciamla %x %n float :: %f",s1,n,n,f);
		System.out.println("string value= "+s1+" num= "+n+" hexadeciamla "+n+" float :: "+f);
		System.out.print("string value= "+s1+" num= "+n+" hexadeciamla "+n+" float :: "+f);


		String str=String.format("%nstring value= %s %n num= %d %n hexadeciamla %x %n float :: %f",s1,n,n,f);
		
		System.out.println(str);
				
	}

}
