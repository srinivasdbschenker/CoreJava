package com.nt.io;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter name:: ");
		String name=sc.nextLine();
		
		System.out.println("enter gender");
		char gen=sc.next().charAt(0);
		System.out.println("enter mobile no");
		long mobileno=sc.nextLong();
		System.out.println("enter age:: ");
		int age=sc.nextInt();
		System.out.println("enter cgpa");
		double cgpa=sc.nextDouble();
		
		System.out.println("enter short value");
		short s=sc.nextShort();
		System.out.println("enter byte value");
		byte b=sc.nextByte();
		System.out.println("entet boolean value");
		boolean bl=sc.nextBoolean();
		
		System.out.println("name:: "+name+"\n gender :: "+gen+"\n mobile no:: "+mobileno+"\n age:: "+age);
		System.out.println("cgpa:: "+cgpa+"\n short value:: "+s+"\n byte value:: "+b+"\n boolean value:: "+bl);
		
		
	}

}
