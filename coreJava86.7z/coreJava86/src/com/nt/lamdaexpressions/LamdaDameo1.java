package com.nt.lamdaexpressions;

public class LamdaDameo1 {
	
	
	
	interface MyInter{
		
		void message();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyInter mi=()->{System.out.println("Hello how r u");};
		
mi.message();
	}

}
