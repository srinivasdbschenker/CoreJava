package com.nt.oops;

public class AccessDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccessmethodDemo a=new AccessmethodDemo();
		a.setAge(20);
		a.setName("raja");
		
		System.out.println("name;: "+a.getName());
		System.out.println("age:: "+a.getAge());
		
	}

}
