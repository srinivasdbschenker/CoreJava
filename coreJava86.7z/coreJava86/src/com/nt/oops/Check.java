package com.nt.oops;

public class Check {

	void swap(Employee obj){
		int temp=obj.id1;
		obj.id1=obj.id2;
		obj.id2=temp;
	}
}
