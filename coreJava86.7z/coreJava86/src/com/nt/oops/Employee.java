package com.nt.oops;

public class Employee {

	
	int id1, id2;
	Employee(int id1,int id2){
		this.id1=id1;
		this.id2=id2;
	}
}
