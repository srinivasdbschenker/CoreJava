package com.nt.oops;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Matrix {
	
	
	int arr[][];
	int r,c;
	
	Matrix(int r, int c){
		this.r= r;
		this.c=c;
		
		arr=new int[r][c];
				
	}
	
	int[][] getMatrix()throws IOException{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		StringTokenizer st;
		
		for(int i=0; i<r; i++){
			String s=br.readLine();
			st=new StringTokenizer(s, " ");
			for(int j=0; j<c; j++)
				arr[i][j]=Integer.parseInt(st.nextToken());
		}
		return arr;
		
	}
	
	
	int[][] findSum(int a[][] , int b[][]){
		int temp[][]=new int[r][c];
		for(int i=0;i<r; i++)
			for(int j=0; j<c;j++)
				temp[i][j]=a[i][j]+b[i][j];
				
				
		return temp;
		
	}
	
	void displayMatrix(int res[][]){
		for(int i=0; i<r;i++){
			for(int j=0;j<c; j++){
				System.out.print(res[i][j]+"\t");
				
			}
			System.out.println();
		}
	}
	
	
	

}
