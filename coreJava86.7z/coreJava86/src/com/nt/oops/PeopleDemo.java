package com.nt.oops;

public class PeopleDemo {
	
	static{
		System.out.println("i am static block");
	}
	
	static boolean talk1(){
		System.out.println("talk1 method");
		return true;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("main started");
		
		System.out.print(PeopleDemo.talk1());
		
		System.out.print(PeopleDemo.talk1());
		System.out.print(PeopleDemo.talk1());
		
		Pepole p=new Pepole();
		
		System.out.println("after object creation");
		p.talk();
		Pepole p1=new Pepole();
		p1.talk();
		
		Pepole p2=new Pepole("rani",20);
		p2.talk();
		
		System.out.println("main ended");
	}

}
