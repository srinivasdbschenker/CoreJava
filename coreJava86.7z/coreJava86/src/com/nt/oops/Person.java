package com.nt.oops;

 class Person {
	
	/*String name ="raja";
	int age =20;
	*/
	
	String name ;
	int age ;
	
	float talk(){
		System.out.println("my name :: "+name);
		System.out.println("my age :: "+age);
		int x=4;
		int y=5;
		int z=x+y;
		return z+100;
	}

}
