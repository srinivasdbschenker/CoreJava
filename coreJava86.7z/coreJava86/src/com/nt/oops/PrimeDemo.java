package com.nt.oops;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimeDemo {

	public static void main(String[] args) throws NumberFormatException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("how many primes? ");//10
		
		int max=Integer.parseInt(br.readLine());
		
		Primes.generate(max);//10
		
		Primes p=Primes.prime();
		
		System.out.println(p);
		
		Class c=Class.forName("com.nt.oops.Primes");
		
		Primes p1=(Primes) c.newInstance();
		
		p1.generate(5);
		
		
		

	}

}
