package com.nt.oops;

public class Primes {
	static boolean prime(long num){//2
		boolean isPrime = true;
		
		for(int i=2; i<=num-1 ; i++)
			if(num%i == 0) isPrime =false;
			
			return isPrime;
		
	}
	
	static void generate(long max){//10
		long c=1, num=2;
		while(c<=max){//1<=10 2<10 3<4 3<5
			if(prime(num)){// 2 3 4
				System.out.println(num);//2 3 5
				++c; //2 3 4
			}
			++num; //3 4 6
		}
	}
	
	static Primes prime(){//2
		int num=4;
		boolean isPrime = true;
		
		for(int i=2; i<=num-1 ; i++)
			if(num%i == 0) isPrime =false;
		return null;
			
			
		
	}
	

}
