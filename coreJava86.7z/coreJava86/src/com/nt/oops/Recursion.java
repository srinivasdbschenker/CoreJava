package com.nt.oops;

public class Recursion {
	
	static long factorial(int num){
		long result;
		
		if(num==1) return 1;
		result=factorial(num-1)*num; // f(4)*5  f(3)*20 f(2) *60 f(1)*120 120
		
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("factorial of 5");
		System.out.println(Recursion.factorial(5));

	}

}
