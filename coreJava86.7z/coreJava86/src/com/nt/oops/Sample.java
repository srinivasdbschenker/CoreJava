package com.nt.oops;

public class Sample {
	
	 int x=55;
	
	Sample(){
	//	System.out.println("sample defualt construcotr");
		this(55);
		//this(33.4);
		
		
		this.access();
		}
	
	Sample(int x){
		
		this.x=x;
	}
	Sample(double y){
		//int y=y;
	}
	
	void access(){
		System.out.println("x :: "+x);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
               Sample s=new Sample();
        //System.out.println(x);       
	}

}
