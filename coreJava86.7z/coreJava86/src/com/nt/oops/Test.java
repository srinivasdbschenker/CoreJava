package com.nt.oops;

public class Test {

	
	int x=10;
	int y=20;
	
	void display(){
		System.out.println("x values :: "+x);
		System.out.println("y value is :: "+y);
	}
}
