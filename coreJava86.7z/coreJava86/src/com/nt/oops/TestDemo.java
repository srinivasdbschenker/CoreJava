package com.nt.oops;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test t=new Test();
		t.x=15;
		t.y=25;
		t.display();
		Test t1=new Test();
		t1.display();
		

	}

}
