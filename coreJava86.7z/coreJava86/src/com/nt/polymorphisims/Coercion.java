package com.nt.polymorphisims;

public class Coercion {
	
	public void sum(){
		System.out.println("the sub  method ");
	}
	public void sum(int a){
		System.out.println("the a value :: "+a);
	}
	public void sum(int a, int b){
		System.out.println("tha a and b values are :: "+(a+b));
	}
	
	public static void main(String[] args){
		// Coercion is the automatic conversion between differenct data types
		// done by the compiler
		
		
		int i=10;
		double d=i;
		System.out.println(i);
		System.out.println(d);
		
		double f=34.2;
		int j=(int) f;
		//conversion is an explicit change in the data types specified by the 
		//cast operator
	Coercion c=new Coercion();
	c.sum();
	c.sum(2);
	c.sum(5, 4);
		
	}

}
