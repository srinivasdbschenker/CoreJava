package com.nt.polymorphisims;

public class Poy {

	
	/*
	 * can we take private methods and final methods as same?
	 * yes. the java compiler assigns the value  for the private methods at the time of compilation. 
	 * also private methods can not be modified at run time. this is the same case with final methods
	 * aso. 
	 * neither the private methods not the final methods can be overriden 
	 * so private methods can be taken as final methods
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a=10;
		
		a=11;
		final int x=12;
	
		One o=new Two();
		o.calculate(25);
		
		One o1=new One();
		o1.calculate(5);
		o1.method1();
		o1.method1(2);
		
		Two t=new Two();
		t.calculate(25);
		t.method1();
		t.method1(23);
		t.method2();
	//t.cal();
		
		/*Two t1=(Two) new One();
		t1.calculate(625);
*/
	}

}
