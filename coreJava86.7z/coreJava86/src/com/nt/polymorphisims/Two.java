package com.nt.polymorphisims;

/*
 * can you override private methods?
 * No . private methods are not available in the sub classes . so they cannot be overriden
 * 
 */
public class Two extends One {
	private int a;
	 final int y=101012345;
	
	final void method2(){
		System.out.println("Helloto");
	}
	private void cal(){
		System.out.println("private");
	}

	static void calculate(double x){
		System.out.println("square root = "+Math.sqrt(x));
	}

}
