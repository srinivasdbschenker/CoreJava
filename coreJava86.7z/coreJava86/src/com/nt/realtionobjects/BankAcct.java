package com.nt.realtionobjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class BankAcct {

	private double bal;
	
	BankAcct(double b){
		bal = b;
		
	}
	
	
	void contact(double r) throws IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter Passwrod");
		
		String passwd=br.readLine();
		
		if(passwd.equals("xyz123")){
			Interest in=new Interest(r);
			
			in.calculateInterest();
			
			
		}else{
			System.out.println("sorry , you are not authorised person");
			return ;
		}
		
	}//contact
	
	private class Interest{

		private double rate;
		
		public Interest(double r) {
			 rate = r;
		// TODO Auto-generated constructor stub
		
		}
		void calculateInterest(){
			double interest=bal*rate/100;
			
			bal+=interest;
			System.out.println("updated balance :: "+bal);
		}
		
	}

}
