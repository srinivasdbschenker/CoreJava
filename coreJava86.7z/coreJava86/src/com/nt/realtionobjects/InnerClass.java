package com.nt.realtionobjects;

import java.io.IOException;

public class InnerClass {
	
	public static void main(String[] args) throws IOException{
		
		BankAcct b=new BankAcct(100000);
		
		b.contact(9.5);
		
		
		
	}

}
