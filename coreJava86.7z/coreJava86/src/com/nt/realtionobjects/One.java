package com.nt.realtionobjects;

public class One {
	//Let us c yeshwath kanithkar
	//java complete reference 
	int x;
	Two t;
	
	One(Two t){
		System.out.println("one's cons started");
		this.t=t;
		x=10;
		System.out.println("ones class construcotr");
	}
	
	void display(){
		System.out.println("One's x---"+x);
		t.display();
		System.out.println("Two's var == "+t.y);
	}

}
