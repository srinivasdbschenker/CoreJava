package com.nt.realtionobjects;

public class Relate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Two obj2=new Two(22);
		
		One obj1=new One(obj2);
		
		obj1.display();

	}

}
