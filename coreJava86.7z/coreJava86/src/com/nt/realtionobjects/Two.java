package com.nt.realtionobjects;

public class Two {
	int y;
	
	Two(int y){
		this.y=y;
		System.out.println("two's construcctor");
	}
	
	void display(){
		System.out.println("two's y= "+y);
	}

}
