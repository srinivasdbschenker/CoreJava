package com.nt.strings;

public class StringbuuferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hello";
		System.out.println("s addres:: "+s.hashCode()+" s value s"+s);
		s="hi";
		System.out.println("s address :: "+s.hashCode()+" s "+s);
		StringBuffer sb=new StringBuffer("Hello");
		System.out.println(sb+" value :: adress  "+sb.hashCode());
		sb.append("Hi");
		System.out.println("sb value is :: "+sb.hashCode()+" s b"+sb);
		
		
		StringBuilder sb1=new StringBuilder("hello");
		System.out.println("sb1"+sb1+"address "+sb1.hashCode());
		
		sb1.append("hi");
		System.out.println("sb1 "+sb1+"adreess:: "+sb1.hashCode());
		

	}

}
