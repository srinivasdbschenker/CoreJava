package com.nt.threads;

import java.io.IOException;

public class Demo1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		MyThread obj=new MyThread();
		
		Thread t =new Thread(obj);
		 
		
		t.start();
		
		System.in.read(); //wait till enter key pressed

	}

}
