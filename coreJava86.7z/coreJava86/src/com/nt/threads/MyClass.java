package com.nt.threads;

public class MyClass extends Thread{

	int count=0;
	
	public void run(){
		for(int i=1; i<=10000;i++)
			count++;
		
		System.out.println("completed Thread "+Thread.currentThread().getName());
		
		System.out.println("its priority : "+Thread.currentThread().getPriority());
			
			
		
	}
}
