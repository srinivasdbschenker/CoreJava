package com.nt.threads;

public class MyThread extends Thread {

	boolean stop=false;
	public void run(){
		for(int i=1; i<=100000;i++){
			System.out.println(i);
			
			if(stop) return;
		}
	}
}
