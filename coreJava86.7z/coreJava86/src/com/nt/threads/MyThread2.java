package com.nt.threads;

public class MyThread2 implements Runnable {

	
	String str;
	MyThread2(String str){
		this.str = str;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1; i<=10; i++){
			System.out.println(str+" : "+ i);
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
