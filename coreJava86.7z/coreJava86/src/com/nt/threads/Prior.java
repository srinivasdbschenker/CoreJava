package com.nt.threads;

public class Prior {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass obj=new MyClass();
		
		Thread t1=new Thread(obj, "one");
		Thread t2=new Thread(obj, "Two");
		
		t1.setPriority(2);
		t2.setPriority(Thread.NORM_PRIORITY);
		
		t1.start();
		t2.start();

	}

}
