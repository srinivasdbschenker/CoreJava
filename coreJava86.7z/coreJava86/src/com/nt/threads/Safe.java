package com.nt.threads;

public class Safe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Reserve1 obj=new Reserve1(1);
		
		
	Thread t1=new Thread(obj);
	Thread t2=new Thread(obj);
	
	t1.setName("first person");
	t2.setName("second Person");
	
	t1.start();
	t2.start();

	}

}
