package com.nt.threads;

public class Single {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyThread1 obj=new MyThread1();
		Thread t1=new Thread(obj);
		
		t1.start();

	}

}
