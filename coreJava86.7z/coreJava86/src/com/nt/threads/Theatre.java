package com.nt.threads;

public class Theatre {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyThread2 obj1=new MyThread2("cut the ticket");
		MyThread2 obj2=new MyThread2("show the seat");
		
		
		Thread t1=new Thread(obj1);
		Thread t2=new Thread(obj2);
		
		t1.start();
		t2.start();
		
		
	}

}
