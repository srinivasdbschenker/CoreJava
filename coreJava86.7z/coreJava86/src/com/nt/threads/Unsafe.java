package com.nt.threads;

public class Unsafe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Reserve obj=new Reserve(1);
		
		Thread t1=new Thread(obj);
		Thread t2=new Thread(obj);
		
		t1.setName("First person");
		t2.setName("Second person");
		
		t1.start();
		t2.start();

	}

}
