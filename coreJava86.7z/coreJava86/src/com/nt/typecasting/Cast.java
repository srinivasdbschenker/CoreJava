package com.nt.typecasting;

/*
 * => if the super class reference is used to refer to super class object , naturally all the methods
 * in super class are accessable
 * 
 * => if the sub clas reference is used to refere to sub class object. all the methods of the 
 * super class as well sub class are accessbile since the sub class object avails a copy of super 
 * class
 * 
 * if widening is done by using sub class object , only the super class methods are accessible  .
 * they are overriden , then only the sub class methods are accessible
 * 
 * 
 * if narrowing is done by using super class object , then none of the super class or sub class methods
 * are accessbile . this is use less
 * 
 * if narrowing is done by using sub class object , then all the methods of both the super classes are
 * avialable to the programmer
 * 
 * 
 */
public class Cast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		One o=new One();
		o.show1();
		Two t=new Two();
		t.show1();
		t.show2();
		
		One o1=new Two();
		o1.show1();
try{	
Two t1=(Two) new One();
t1.show1();
t1.show2();

}catch(Exception e){
	e.printStackTrace();
}
One o2;

o2=new Two();

Two t2 =(Two) o2;
 t2.show1();
 t2.show2();
 
 
		
	}

}
