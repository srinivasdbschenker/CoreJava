package com.nt.typecasting;

public class CloneDemo {
public void sum() throws CloneNotSupportedException{
	
	Employee e6=new Employee(12,"rani");
	e6.getData();
	
	Employee e7=(Employee) e6.myClone();
	e7.getData();
}
	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		
		Employee e1=new Employee(100, "Srinivas");
		
		e1.getData();
		
		Employee e2=(Employee) e1.myClone();
		e2.getData();
		
		Employee e3=new Employee(11, "raja");
		e3.getData();
		
		CloneDemo d=new CloneDemo();
		d.sum();
		
		Employee e4= (Employee) e3.myClone();
		e4.getData();
		
		

	}

}
