package com.nt.typecasting;

public class KnowName {

	
	static void printName(Object obj){
		Class c=obj.getClass();
		System.out.println(c);
		String name=c.getName();
		
		System.out.println("the class name ::: "+name);
	}
}
