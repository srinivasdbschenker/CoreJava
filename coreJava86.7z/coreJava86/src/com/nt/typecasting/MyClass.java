package com.nt.typecasting;

public class MyClass {
	
	int x;
	
	MyClass(int x){
		this.x=x;
	}

}
