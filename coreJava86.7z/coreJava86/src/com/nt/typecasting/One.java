package com.nt.typecasting;

public class One {

	void show1(){
		System.out.println("super class method");
	}
}
