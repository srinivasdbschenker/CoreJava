package com.nt.typecasting;

public class PrimitiveCastingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	 int i=10;
	 double x=i;// implicit casting
	 int y=(int) x;
	 
	 System.out.println("i :: "+i);
	 System.out.println(" x :: "+x);
	 System.out.println("y :: "+y);
	 

	}

}
