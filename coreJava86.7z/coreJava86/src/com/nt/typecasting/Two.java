package com.nt.typecasting;

public class Two  extends One{

	void show2(){
		System.out.println("sub class method");
	}
}
