package com.nt.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ArithmaticInput {

	public static void main(String[] args) throws IOException   {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
System.out.println("enter two numbers");

String str=br.readLine();

StringTokenizer st=new StringTokenizer(str, ",");

String s1=st.nextToken();
String s2=st.nextToken();

s1=s1.trim();
s2=s2.trim();


double n1=Double.parseDouble(s1);
double n2=Double.parseDouble(s2);

System.out.println("n1:: "+n1+" n2:: "+n2);
System.out.println("addintion:: "+(n1+n2));
System.out.println("sub:: "+(n1-n2));
System.out.println("mul: "+ (n1*n2));

System.out.println("div:: "+(n1/n2));
System.out.println("module :: "+(n1%n2));


		
		
	}

}
