package com.nt.oops;

import java.text.NumberFormat;

public class Circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		final double PI=(double)22/7;
		double r=15.5;
		double area=PI*r*r;
		System.out.println("Area= "+area);
		
	
		NumberFormat obj=NumberFormat.getNumberInstance();
		
		obj.setMaximumFractionDigits(2);
		obj.setMinimumIntegerDigits(7);
		
		String str=obj.format(area);
		System.out.println("formated area :: "+str);
	}

}
