package com.nt.basics;

public class DotDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DotEX de=new DotEX();
		de.a=20;
		de.b=30;
		de.c='a';
		System.out.println("a value is "+de.a);  //sysout ctrl+spacebar
		
		System.out.println("b value is "+de.b);
		System.out.println("c value is "+de.c);
		

	}

}
