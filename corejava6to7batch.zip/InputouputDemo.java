package com.nt.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputouputDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter character");

		//char c=(char) br.read();
		char c=br.readLine().charAt(3);
		System.out.println("charcter ch:: "+c);
		
		//br.skip(3);
		System.out.println("enter string value");
		
		String s=br.readLine();
		System.out.println("the string s:: "+s);
		
		System.out.println("enter integer vale");
		
		int i=Integer.parseInt(br.readLine());
		System.out.println("the integer value:: "+i);
		
		
		System.out.println("enter float value");
		
		float f=Float.parseFloat(br.readLine());
		
		System.out.println("float value is:"+f);
		
		System.out.println("enter double value");
		double d=Double.parseDouble(br.readLine());
		
		System.out.println("double value : "+d);
		
		
		System.out.println("enter byte balue");
		byte b=Byte.parseByte(br.readLine());
		
		System.out.println("byte value :: "+b);
		
		System.out.println("enter short value");
		short s1=Short.parseShort(br.readLine());
         System.out.println("short:: "+s1);	
         
         System.out.println("boolen vlaue enter");
         boolean b1=Boolean.parseBoolean(br.readLine());
         System.out.println("boolean :: "+b1);
         
         System.out.println("enter long value");
         
         long l=Long.parseLong(br.readLine());
         System.out.println("long :: "+l);
         
         
	}

}
