package com.nt.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LeapDemo {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter year no;: ");
		
		int year=Integer.parseInt(br.readLine());
		
		if(year%100 == 0 && year % 400==0)
			System.out.println("it is leap year");
		else if(year %100 !=0  && year % 4 ==0)
			System.out.println("it is leap year");
		else 
			System.out.println("it is not leap");
		
		
		System.out.println("-----------------------------------");
		System.out.println("how many fibonacss ?");
		
		int n=Integer.parseInt(br.readLine());
		long f1=0, f2=1;
		
		System.out.println(f1);
		System.out.println(f2);
		long f=f1+f2;
		System.out.println(f);
		
		int count =3;
		
		while(count<n){
			f1=f2;
			f2=f;
			f=f1+f2;
			System.out.println(f);
			count++;
		}
		
		
		
		

	}

}
