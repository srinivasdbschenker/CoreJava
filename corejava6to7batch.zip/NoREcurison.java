package com.nt.oops;

public class NoREcurison {
	
	static long factorial(int num){
		long fact=1;
		while(num>0)
			fact *= num--;
		
		
		return fact;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("factorial of 5:: ");
		System.out.println(NoREcurison.factorial(5));
		

	}

}
