package com.nt.oops;

public class PassObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee obj1=new Employee(10,20);
		Check obj=new Check();
		System.out.println(obj1.id1+" \t"+obj1.id2);
		
		obj.swap(obj1);
		System.out.println(obj1.id1+"\t"+obj1.id2);

	}

}
