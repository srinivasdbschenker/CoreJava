package com.nt.oops;

public class Pepole {

	String name;
	int age;
	
	static{
		System.out.println("people static ");
	}
Pepole(){
		System.out.println("the defualt construcotr");
		name="raja";
		age=22;
		
	}
	


	
	
	public Pepole(String s, int i) {
		// TODO Auto-generated constructor stub
		
		name=s;
		age=i;
	}

	void talk(){
		System.out.println("hello my name is :: "+name);
		System.out.println("my age is ::; "+age);
	}
	
	// file.java--> filename.class--> jvm--> load class asign memory
	
		
	
}
