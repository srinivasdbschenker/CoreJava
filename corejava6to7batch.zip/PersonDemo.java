package com.nt.oops;

public class PersonDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("main started");
		
		Person p=new Person();
		p.name="rani";
		p.age=20;
		System.out.println("object created and called talk method");
		System.out.println(p.talk());
		System.out.println("conteorller in main method");

	}

}
