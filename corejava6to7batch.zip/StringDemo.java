package com.nt.strings;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello";
		System.out.println("s is "+s+" address s :: "+s.hashCode());
        
		s="hi";
		System.out.println("s is "+s+" address s :: "+s.hashCode());
        
		
		String s1=new String("raja");
		System.out.println("s1 :: "+s1+" address s1:: "+s1.hashCode());
		String s4=new String("raja");
		System.out.println("s4 :: "+s4+" address s4:: "+s4.hashCode());
		s4="rajaa";
		System.out.println("s4 :: "+s4+" address s4:: "+s4.hashCode());
		
		s1="Hello";
		System.out.println("s1 is "+s1+" address s1 :: "+s1.hashCode());
        
		
		//System.out.println("s1 :: "+s1+" address s1:: "+s4.hashCode());
		
     char[] c={'a','p','p','l','e','s'};
     String s2=new String(c);
     
     System.out.println("s2:: "+s2 +" address s2:: "+s2.hashCode());
     
     String s3=new String(c,2,3);
     System.out.println("s3:: "+s3 +"address s3:: "+s3.hashCode());
	
}
}
