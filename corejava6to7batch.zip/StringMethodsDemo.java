package com.nt.strings;

public class StringMethodsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello";
		String s1="World";
		System.out.println(s.concat(s1));
		System.out.println(s.concat("Good Morning"));
		
		System.out.println("length of String s:: "+s.length());
		System.out.println("lenght of string s1:: "+s1.length());
		
		System.out.println("2 location"+s.charAt(2));
		System.out.println("3location "+s1.charAt(3));
		
		System.out.println("comparee :: "+s1.compareTo(s));
		System.out.println("compare:: "+s.compareTo("Hello"));
		
		System.out.println("compare"+s.compareTo("HELLO"));
		
		System.out.println("compare "+s.compareToIgnoreCase("HELLO"));
		
		
		
		
		System.out.println("equals ::: "+s.equals(s1));
		System.out.println("equals:: "+s.equals("Hello"));
		System.out.println("equals:: "+s.equalsIgnoreCase("HELLO"));
		System.out.println("equals:: "+s.equals("HELLO"));
		
		
		System.out.println("starts with:: "+s.startsWith("H"));
		System.out.println("starts with :: "+s.startsWith(s1));
		
		System.out.println("end with :: "+s.endsWith(s1));
		System.out.println("end with :: "+s.endsWith("o"));
		
		
		
		String str="Hello , this is naresh it ";
		char arr[]=new char[20];
		
		str.getChars(7, 21, arr, 2);
		System.out.println(arr);
		
		String s3[];
		s3=str.split(" ");
		
		for(int i=0;i<s3.length;i++){
			System.out.println(s3[i]);
		}
		
		
		String s4="Hello";
		
	   String s5=new String("Hello");
	   System.out.println(s4.hashCode()+ " "+s5.hashCode());
	   System.out.println(s4==s5);

	   
	   /*
	    * explain the difference between 
	    * String s4="Hello";
	    * 	   String s5=new String("Hello");?
	    * in the first statment , assignment operator is used to assign the string literal to the 
	    * string variables.
	    * in this case, JVM first of all check whether the same object is already avialable in the 
	    * string constant pool
	    * if it is avaialable ,then it creates another reference to it. 
	    * if the same object is not avaialbe then it creates  another object with the content "Hello"
	    * and stores in into the string constant pool
	    *  
	    *  in the second statment  new operator is used to create the string object , in this case
	    *  jvm always creates a new object without looking in the string constant pool
	    *  
	   
	    * 
	    * what is Object reference 
	    * 
	    * object reference is a uniuque Hexadecimal number representing the memory address of the obj
	    * it is usefull to access the number of the object
	    * 
	    * 
	    * what is the difference between == and equals() while comparing stirngs? which one is reliable?
	    * == operator compares the reference of the string objects
	    * it does not compare the contents of the objects
	    * equals() method compares the contents 
	    * while comparing the strings,equals() method should be used as it yields the correct result
	    * 
	    * 
	    * 
	    */
	   
	   
	   
	   
	   
	   
	
	}

}
