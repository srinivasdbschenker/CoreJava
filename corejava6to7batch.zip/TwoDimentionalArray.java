package com.nt.arrays;

import java.util.Scanner;

public class TwoDimentionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//3 2
		int a[][]={{10,11},{12,13},{14,15}};
		Scanner sc=new Scanner(System.in);
		
		
		int[][] b=new int[2][3];
		for(int i=0; i<2; i++){
			for(int j=0; j<3; j++){
				System.out.println("enter value");
				b[i][j]=sc.nextInt();
				
				
			}//j loop
		}//i loop

		for(int i=0; i<3; i++){
			for(int j=0;j<2;j++){
				System.out.print("a["+i+"]["+j+"]  "+a[i][j]+"   ");
			}
			System.out.println();
		}

System.out.println("\n\n");
		for(int i=0; i<2; i++){
			for(int j=0;j<3;j++){
				System.out.print("b["+i+"]["+j+"]  "+b[i][j]+" ");
			}
			System.out.println();
		}
		
	}//main

}//clas
