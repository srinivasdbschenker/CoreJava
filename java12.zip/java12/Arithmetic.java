import java.lang.*;

class Arithmetic{

public static void main(String[] args){

System.out.println("HI How r you.. i want arithmetic operation");

//int float double char boolean long short 

int x=65;
int y=35;
int z;
z=x+y;

System.out.println("the sum of x annd y is :: "+z);

int a;
a=x-y;

System.out.println("the x-y :: "+a);

System.out.println("mulitplication of x and y"+(x*y));
System.out.println("the division of x/y:: "+ (x/y));
System.out.println("the module of x%y:: "+(x%y));

}

}