/*
*If demo is discussing about if control statement
*using if demo we finding even number and odd number
*/
public class IfDemo{
public static void main(String[] args){



int x=6;
System.out.println("if started");
if(x%2 == 0){
System.out.println("x is even number");
}else{
System.out.println("x is odd number");

}

System.out.println("if else is endeded");


}

}