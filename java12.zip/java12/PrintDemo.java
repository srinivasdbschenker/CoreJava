class PrintDemo{

public static void main(String[] args){

System.out.println("HI how are you");

System.out.print("Good Morning");
System.out.println("Welcome to java");
System.out.println("HI how are you");
System.out.print("Java is Beautifull language");
System.out.println("HI how are you");

}
}