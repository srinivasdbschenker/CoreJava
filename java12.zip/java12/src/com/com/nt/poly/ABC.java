package com.com.nt.poly;

class ABC {
    //----
   // private class DEF{
        //----
   // }
}
