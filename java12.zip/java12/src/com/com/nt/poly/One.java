package com.com.nt.poly;

/*
 * what is the difference between dynamic polymorphisim and static polymorphsim?
 * dynamic polymorphism is the polymorphism exhibited at runtime.
 * here , java compiler does not understand which method is called at compilation time
 * only jvm decides which method is called at runtime
 * method overloading and method overriding using instance methods are the examples for dynamic polymorphsim
 *
 * static polymorphism is the polymorphism exhibited at compile time
 * here java compiler knows which method is called
 * method overrloding and method overriding using static methods , method overiding using private or final
 * methos are examples for stati polymorphism
 *
 */
public  class One {
    final double PI=3.14;
int pi=2;

    private void cal(){
        System.out.println("private");
    }

    private void cal(int a){
        System.out.println("private a");
    }
    static void calculate(double x){
        System.out.println("square value= "+(x*x));
    }
    static void calculate(double x,int y){
        System.out.println("square value= "+(x*y));
    }
    final void method1(){

        System.out.println("Hello");
    }

    final void method1(int a){
        System.out.println("Hello");
    }
}
