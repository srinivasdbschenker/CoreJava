package com.com.nt.poly;

public class Three extends Two {
    int pi=4;
    final void method3(){
        System.out.println("Helloto");
        System.out.println("pi :: "+pi);

        System.out.println(" Three pi super :: "+super.pi);
        System.out.println("PI" + PI);
    }


}
