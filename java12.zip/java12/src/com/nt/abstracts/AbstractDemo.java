package com.nt.abstracts;

public class AbstractDemo {
    public static void main(String[] args) {
        Circle c=new Circle();
        Rectagle r=new Rectagle();
        Square s=new Square();

        c.area();
        c.sum();
       Myclass m=new Circle();
       m.area();
       m.sum();




    }
}
