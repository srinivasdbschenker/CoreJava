package com.nt.abstracts;

public abstract class Car {
    int regno;
    int PI=3;

    Car(int regno){
        this.regno=regno;
    }

    public void opentTank(){
        System.out.println("fill the tank");
    }

    abstract void useBreak();
    abstract void steering();





}
