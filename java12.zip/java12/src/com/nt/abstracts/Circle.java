package com.nt.abstracts;

public class Circle extends Myclass{

    Circle(){
        System.out.println("circle constructor");

    }

    @Override
    public void area() {
        System.out.println("2*2 :: "+(3.14*2*2));

    }
}
