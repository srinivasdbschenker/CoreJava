package com.nt.abstracts;

public class HpPrinter extends Printer{
    String s1;


    HpPrinter(String s) {

        super(s);
        this.s1=s;
        System.out.println("s : "+s);
    }

    @Override
    public void print1() {
        System.out.println("HP s1 :: "+s1);
    }

    @Override
    public void printit(String s) {
        System.out.println("HP the text is :: "+s);
    }


}
