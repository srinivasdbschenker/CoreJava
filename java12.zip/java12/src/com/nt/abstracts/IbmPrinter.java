package com.nt.abstracts;

public class IbmPrinter extends  Printer {
    String s1;

    IbmPrinter(String s) {
        super(s);
        this.s1=s;
        System.out.println("s :: "+s);
    }

    @Override
    public void print1() {
        System.out.println("IBM s1:: "+s1);
    }

    @Override
    public void printit(String s) {
        System.out.println("IBM text is ::: "+s1);
    }
}
