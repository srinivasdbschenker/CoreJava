package com.nt.abstracts;

public interface MyInter {
    int PI=3;


    void sum(); //public abstract  implements


}
