package com.nt.abstracts;

public abstract class Myclass {
    int x=10;

    Myclass(){
        System.out.println("myclass");
    }
    public void sum(){
        System.out.println("sum is "+(2+2));
    }


    public abstract void area(); //


}
