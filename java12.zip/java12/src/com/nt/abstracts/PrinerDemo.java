package com.nt.abstracts;

public class PrinerDemo {
    public static void main(String[] args) {
        HpPrinter h2;
        //h2 = new HpPrinter();
        HpPrinter h=new HpPrinter("This is my Java class Abstract Text");
        IbmPrinter i=new IbmPrinter("abstract is contain zero or more abstract methods");
  h.print1();
  h.printit("prit");

        Printer p = h;
        p.printit("HI ");
        p.print1();
        System.out.println("--------------");
        Printer p1;
        p1=i;
        p1.printit("how are ");
        p1.print1();
    }
}
