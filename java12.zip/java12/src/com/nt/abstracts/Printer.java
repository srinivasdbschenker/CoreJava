package com.nt.abstracts;

public abstract  class Printer {
    String text;


    Printer(String s){
        this.text=s;

    }


    public void sunTest(){
        System.out.println("text:: "+text);
    }

    public abstract void print1();
    public abstract void printit(String text);

}
