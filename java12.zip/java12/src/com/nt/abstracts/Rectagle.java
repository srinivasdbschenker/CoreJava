package com.nt.abstracts;

import org.w3c.dom.css.Rect;

public class Rectagle  extends  Myclass{

    Rectagle(){
        System.out.println("Rectangle constructor");
    }
    @Override
    public void area() {
        System.out.println(" area of rectangle :: "+(2*3));

    }
}
