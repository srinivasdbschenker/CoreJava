package com.nt.abstracts;

public class Santro extends  Car {

    Santro(int regno) {
        super(regno);
    }

    @Override
    void useBreak() {
        System.out.println("air/gas breaks ");
    }

    @Override
    void steering() {
        System.out.println("ordnery steering");
    }
}
