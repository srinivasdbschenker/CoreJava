package com.nt.abstracts;

public class Square  extends  Myclass{

    Square(){
        System.out.println("Square Construcotr");
    }

    @Override
    public void area() {
        System.out.println("area of square ;: "+(3*3));
    }
}
