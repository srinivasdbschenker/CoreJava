package com.nt.abstracts;

public class UseCarDemo {
    public static void main(String[] args) {

        Maruti m=new Maruti(9999);
        Santro s=new Santro(1111);

        Car c;
        Car c1;

         //Car c=new Car(999);
        c=m; //Car c=new Maruti(9999);
        c.opentTank();
        c.steering();
        c.useBreak();

        System.out.println("-----------");
        c1=s;
        c1.opentTank();
        c1.steering();
        c1.useBreak();


    }
}
