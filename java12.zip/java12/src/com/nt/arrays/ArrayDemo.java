package com.nt.arrays;

import java.util.Scanner;

public class ArrayDemo {
    public static void main(String[] args) {
        System.out.println("array demo");
        int a[]=new int[10];
        a[0]=12;
        a[1]=23;
        a[2]=21;
        a[3]=12;
        a[4]=32;
        a[5]=43;
        a[6]=54;
        a[7]=65;
        a[8]=43;
        a[9]=34;

        System.out.println(a[0]);
        System.out.println(a[1]);

        System.out.println(a[2]);

        System.out.println(a[3]);

        System.out.println(a[4]);

        System.out.println(a[5]);

        System.out.println(a[6]);

        System.out.println(a[7]);
        System.out.println(a[8]);
        System.out.println(a[9]);

        System.out.println("-------------------------------------");

        int[] b=new int[5];

        Scanner sc=new Scanner(System.in);

        for(int i=0; i<5;i++){
            System.out.println("enter array values ");
            b[i]=sc.nextInt();

        }


        System.out.println("the array elements are");  //b[0]=23; b[1]=25
        for(int i=0; i<5;i++){
            System.out.println("b["+i+"]  :: "+b[i]);
        }

        //int c[]={23,43,54,65,76,89,98,87,56};
        int[] c={23,43,54,65,76,89,98,87,56};

        for(int i=0; i<9;i++){
            System.out.println("c["+i+"]:: "+c[i]);
        }




    }
}
