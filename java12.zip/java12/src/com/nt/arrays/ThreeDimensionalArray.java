package com.nt.arrays;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class ThreeDimensionalArray {
    public static void main(String[] args) throws IOException {
        Scanner sc=new Scanner(System.in);
        //BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int[][][] a=new int[3][2][4]; // 24 2

        int l=0;
        l=1;
        System.out.println(l);

        for(int i=0;i<2;i++){
            for(int j=0;j<2;j++){
                for(int k=0;k<2;k++){
                    System.out.println("enter the array element");
                   a[i][j][k]=sc.nextInt();
                     // a[i][j][k]=Integer.parseInt(br.readLine());
                }//k
            }//j
        }//i


        for(int i=0;i<3;i++){
            for(int j=0;j<2;j++){
                for(int k=0;k<4;k++){
                    System.out.print("a["+i+"]["+j+"]["+k+"]::"+a[i][j][k]+"  ");
                                    }
                System.out.println();
            }//j
            System.out.println("-----------------------------------");
        }//i




    }
}
