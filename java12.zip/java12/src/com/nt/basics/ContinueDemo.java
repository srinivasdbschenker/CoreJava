package com.nt.basics;

public class ContinueDemo {
    public static void main(String[] args) {

        for(int i=10; i>=1;i--){ //10>=1 T  9>=1 8>=1 t 7>1 t 6>1 t 5>1 t
           if(i>5) continue;   //10>5  T 9>1 t 8>5 t 7>5 t 6>5 t 5>5 F
            System.out.println(i);

        }
        System.out.println("main end");
    }
}
