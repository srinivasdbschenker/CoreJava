package com.nt.basics;

public class DoWhileDemo {
    public static void main(String[] args) {
        int x;

        //do{--}while(condition);

        System.out.println("main start");

        x=11;
        System.out.println("do while demo");


       do {
            System.out.println(x);
            x=x+1;
        }while(x<=10); //12<=10 F
        System.out.println("main end");

    }

}
