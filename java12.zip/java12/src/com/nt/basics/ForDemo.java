package com.nt.basics;

public class ForDemo {
    public static void main(String[] args) {
        System.out.println("main begin");

        //for(intial value; condition; increment/decrement){--}
/*
        for(int i=1;i<=10;i++){
            System.out.println(i);
        }
        System.out.println("------------------");
       int y=1;
        for(;;){
            System.out.println(y);
            y++;
            if(y>10) break;
        }

        */

     int r=5;
     for(int i=1; i<=r; i++){
         for(int st=1; st<=i;st++){
             System.out.print(" * ");
         }
         System.out.println();
     }

        System.out.println("main end");
    }
}
