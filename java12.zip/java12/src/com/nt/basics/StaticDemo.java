package com.nt.basics;

public class StaticDemo {

    static{
        System.out.println("static blocks");
    }


    StaticDemo(){
        System.out.println("intilizing values");
    }

    public StaticDemo(int i) {
        System.out.println("i :: "+i);
    }


    public static void main(String[] args) {
        System.out.println("main started");
        StaticDemo sd=new StaticDemo();

        StaticDemo sd1=new StaticDemo();


        StaticDemo sd2=new StaticDemo(2);

        System.out.println("main endede");
    }
}
