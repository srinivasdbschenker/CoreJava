package com.nt.basics;

public class WhileDemo {
    public static void main(String[] args) {
        //1 2 3 4 5 6 7 8 9 10
        System.out.println("main start");
        int x;
        x=1;
        System.out.println("while demo");

        //while(condition){----}

        while(x<=10){ //11<=10
            System.out.println(x);
            x=x+1;
        }
        System.out.println("main end");
    }
}
