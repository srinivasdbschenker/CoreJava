package com.nt.cloneableobj;

public class ABC implements Cloneable{
    int x, y;
    ABC(){
        x=10;
        y=20;
        //this.sum();
    }

    public void sum(){
        System.out.println(" sum :: x :: "+x+" y ::: "+y);
        //ABC a=new ABC();
    }

    public Object clone() throws CloneNotSupportedException {

        return super.clone();
    }
}
