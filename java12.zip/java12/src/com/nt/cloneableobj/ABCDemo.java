package com.nt.cloneableobj;

public class ABCDemo {
    public static void main(String[] args) throws CloneNotSupportedException {
        System.out.println("main started ");

        ABC a=new ABC();
        System.out.println(" hash code "+a.hashCode());
        System.out.println("a.x:: "+a.x+" a.y : "+a.y);
        a.sum();


        //ABC b=a;
        ABC b= (ABC) a.clone();
        b.sum();
        System.out.println("b hash code :: "+b.hashCode());
        System.out.println("b.x :: "+b.x+" b.y:: "+b.y);

        a.x=11;
        b.x=12;

        System.out.println(" hash code "+a.hashCode());
        System.out.println("a.x:: "+a.x+" a.y : "+a.y);
        System.out.println("b.x :: "+b.x+" b.y:: "+b.y);
        a.sum();


        b.sum();
        System.out.println("b hash code :: "+b.hashCode());

        //float c=10;
        // int d=c;


        //  System.out.println("b.x:: "+b.x+" b.y : "+b.y);

        //System.out.println("main ended");




    }
}
