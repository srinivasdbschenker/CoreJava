package com.nt.cloneableobj;

import java.io.Serializable;

/**
 * 1. if a parent class has implemented serializable interface then child class does not need to implement it but vice-versa is not true.
 * 2. only not-static data members are saved via serialization process.
 * 3. static data members and taransient data membbers  are not saved via serialization process . so , if you do not want to save value of a non static data member then
 * make it transient
 * 4. Constructor of object is never called when an object is deserialized
 * 5. Associated objects must be implementing serializable interface
 *
 */
public class Demo implements Serializable {
   transient public int a ;

    public String b;

static String c= "22";

    public Demo(int a, String b) {
        this.a = a;
        this.b = b;

    }


}
