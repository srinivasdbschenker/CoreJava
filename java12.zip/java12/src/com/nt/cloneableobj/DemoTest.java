package com.nt.cloneableobj;

import java.io.*;

public class DemoTest {
    public static void main(String[] args) {

        Demo demo=new Demo(1,"NareshIt");
        String filename="WelcomeToJava";

        // serialization
        try {

            //saving of object in a file
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(file);
            out.writeObject(demo);

            out.close();
            file.close();
            System.out.println(" object has been serialized");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.gc();


        Demo demo1=null;
        //deserializaiton process
        try {
            FileInputStream  fis=new FileInputStream(filename);
            ObjectInputStream ois=new ObjectInputStream(fis);
            demo1= (Demo) ois.readObject();
            System.out.println(" object has  been deserialized ..");
            System.out.println("a == "+demo1.a);
            System.out.println("b== "+demo1.b);

            ois.close();
            fis.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
