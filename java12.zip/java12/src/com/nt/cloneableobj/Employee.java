package com.nt.cloneableobj;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {

    private int id;
    private String name;
    private float sal;
    private Date doj;

    public Employee(int id, String name, float sal, Date doj) {
        this.id = id;
        this.name = name;
        this.sal = sal;
        this.doj = doj;
    }


    void display(){
        System.out.println(id+"\t"+name+"\t"+sal+"\t"+doj);
    }

    static Employee getData() throws IOException {
                 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        System.out.println("enter emp id:: ");
        int id=Integer.parseInt(br.readLine());

        System.out.println("enter ename:: ");
        String name=br.readLine();

        System.out.println("ente sal :: ");
        float sal=Float.parseFloat(br.readLine());
        System.out.println("doj :: ");
        Date d=new Date();

        Employee e=new Employee(id,name,sal, d);

        return e;

    }

}
