package com.nt.cloneableobj;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class EmployeeDemoDeSer {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

        FileInputStream fis=new FileInputStream("objfile");
        ObjectInputStream ois=new ObjectInputStream(fis);

        Employee e;

        while((e =  (Employee)ois.readObject()) !=null) {
            e.display();
        }


        ois.close();
    }
}
