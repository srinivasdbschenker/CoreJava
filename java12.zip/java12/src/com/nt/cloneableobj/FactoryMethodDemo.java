package com.nt.cloneableobj;

public class FactoryMethodDemo {
    public static void main(String[] args) {
        /*
        *A method in a  java class that is capable of constructing and returning its own java class object
        * is called as static fortory method
        *
        *
         */



        Thread t=Thread.currentThread();
        System.out.println("t:: "+t);
        String s1=String.valueOf(10);

        System.out.println("s1:: "+s1);
/*
* By Using instance Factory method:
* static factory mehtods will called without object , Instance factory method will called by using object
* In order to create a new object for java class by using  exitin object and its data take the support
* of instance factory method
*
 */

         String s2=new String("Raja");

         String s3=s2.concat("Rani");
        System.out.println("s3:: "+s3);

    }
}
