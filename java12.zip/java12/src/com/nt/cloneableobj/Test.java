package com.nt.cloneableobj;

public class Test{
    int x;
    int y;

    Test(){
        x=10;
        y=20;
    }
}
