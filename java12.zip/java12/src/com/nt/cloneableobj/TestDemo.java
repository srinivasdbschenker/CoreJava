package com.nt.cloneableobj;

public class TestDemo {
    public static void main(String[] args) {

        Test t=new Test();
        System.out.println("t.x:: "+t.x+" t.y:: "+t.y);
        System.out.println("hash code t :: "+t.hashCode());

        Test t1=t;
        System.out.println("t.x:: "+t.x+" t.y:: "+t.y);
        System.out.println("t1.x:: "+t1.x+" t1.y:: "+t1.y);

        System.out.println("hash code t1 :: "+t1.hashCode());

        t1.x=100;

        System.out.println("t.x:: "+t.x+" t.y:: "+t.y);
        System.out.println("t1.x:: "+t1.x+" t1.y:: "+t1.y);







    }
}
