package com.nt.collectionss;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Vector;

public class ListDemo {
    public static void main(String[] args) {


        ArrayList a=new ArrayList();
        a.add("raja");
        a.add("rani");

        a.add(10);
        a.add(12.34f);
        a.add('c');
        System.out.println("a:: "+a);
        a.add("raja");
        System.out.println("a:: "+a );
        System.out.println("------------linked list---------------------");
        LinkedList l=new LinkedList();
        l.add("10");
        l.add("rao");
        l.add("rani");
        l.add('a');
        l.add(10);
        System.out.println(l);
       System.out.println("------");
       l.addAll(a);

        System.out.println(l);


        l.addFirst("hyd");
        l.addLast("vizaq");
        System.out.println("s:: "+l);
        l.add(0,"delhi");
        System.out.println(l);
        l.add("rao");


        System.out.println("s:: "+l);

        l.remove(6);
        System.out.println(l);

        System.out.println("-------------Stack--------------");
             Stack s=new Stack();
        System.out.println("is empty:: "+s.empty());
             s.push("10");

        System.out.println(s);

        System.out.println(s.empty());
        s.push("rani");
        s.push('c');
        s.push("raja");
        s.push("10");
        System.out.println(s);

        System.out.println("------------Vector----------------");
        Vector v=new Vector();
        System.out.println("vector capacity "+v.capacity());
        System.out.println("size of the vector::"+v.size());
        for(int i=0; i<10;i++){
            v.add(i);
            //System.out.println(v.add(i));
        }
        System.out.println("v :: "+v);
        System.out.println("vector capacity" +v.capacity());

v.add(10);
        System.out.println("v :: "+v);
        System.out.println("vector capacity :: " +v.capacity());




    }
}
