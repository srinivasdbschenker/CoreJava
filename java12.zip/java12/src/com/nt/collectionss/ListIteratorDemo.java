package com.nt.collectionss;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListIteratorDemo {
    public static void main(String[] args) {

        LinkedList l=new LinkedList();
        l.add("chirru");
        l.add("PK");
        l.add("balaya");
        l.add("nag");
        l.add("venky");

        System.out.println(l);

        ListIterator ltr=l.listIterator();

        while(ltr.hasNext()){
            String s= (String) ltr.next();

            if(s.equals("chirru")){
               ltr.add("ramcharan");
            }

        }
        System.out.println(l);

    }

}
