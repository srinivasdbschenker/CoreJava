package com.nt.collectionss;

import java.util.HashMap;
import java.util.Hashtable;

public class MapDemo {
    public static void main(String[] args) {
        HashMap hm=new HashMap();

        hm.put("1", "raja");
        hm.put("2"," rani");
        hm.put("3" ,"rao1");
        hm.put(null,123);
        hm.put(22,null);
        System.out.println("hm :: "+hm);

       hm.put("3" ,"rao");

        hm.put("4" ,"rao");
        hm.put(5,5);
        hm.put(6,6);
        hm.put(7,5);
        hm.put("7.6",99);
        hm.put(7.0, 88);
         hm.put(null, 1234);


        System.out.println("hm :: "+hm);

        Hashtable ht=new Hashtable();
        ht.put("1", "raja");
        ht.put("2"," rani");
        ht.put("3" ,"rao1");
       // ht.put(null,123);
       // ht.put(22,null);


        System.out.println("ht :: "+ht);

        ht.put("3" ,"rao");

        ht.put("4" ,"rao");
        ht.put(5,5);
        ht.put(6,6);
        ht.put(7,5);
        ht.put(7.0,97);
        ht.put("7",99);


        System.out.println("ht :: "+ht);




    }


}
