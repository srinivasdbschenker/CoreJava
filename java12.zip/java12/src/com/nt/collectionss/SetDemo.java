package com.nt.collectionss;

import java.util.HashSet;
import java.util.TreeSet;

public class SetDemo {
    public static void main(String[] args) {


        HashSet h=new HashSet();
        h.add("raja1");
        h.add("rani1");
       h.add(12);
       h.add('c');
        System.out.println("hashset :: "+h);
        h.add("raja");
        h.add("rao");

        System.out.println("hashset :: "+h);

        TreeSet ts=new TreeSet();
        ts.add("raja");
        ts.add("rani");
       // ts.addAll(h);
       //ts.add(12);
      // ts.add('c');
        System.out.println("tree set :: "+ts);
        ts.add("raja");
        ts.add("rao");
        System.out.println("tree set :: "+ts);


    }
}
