package com.nt.exceptions;

public class CustomExceptionDemo {

    public static void setPriority(int i){
        if(i>11 || i<12){
            throw new IllegalArgumentException();
        }
    }
    public static void m1(){
        m1();
        //it is the child class of Error and it is unchecked .
        // Raised automatically byt the
        //jvm whenever we are performing recursive method invocation
    }
    public static void main(String[] args) {
       // CustomExceptionDemo.setPriority(11);

        int age=Integer.parseInt("70");
        if(age>60){
          throw new TooYoungException("Younger age is already over");
        }else if(age<18){
           throw new TooYoungException("please wait some more time");
        }

        System.out.println("Thanks for register");
       // m1();


    }
}
