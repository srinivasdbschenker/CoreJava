package com.nt.exceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionDemo {
    public static void main(String[] args) {


            int x = 1; //java compiler it is syntactically not correct
            System.out.println("hi how r you ");

        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("enter i values");
            int i=Integer.parseInt(br.readLine());
        } catch (IOException ie) {
            ie.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

        int y = 0;
            int z;
            try {
                z = x / y;
            }catch(ArrayIndexOutOfBoundsException aoe){
                aoe.printStackTrace();
                System.out.println("aoe excepiton");
            }
            catch(ArithmeticException ae){
                ae.printStackTrace();
                System.out.println("ae exception");
            }
            catch(Exception e){
                e.printStackTrace();
                System.out.println("Exception is occures");
            }


        int a[] = new int[10]; //0 9




            a[1] = 10;
            a[10] = 20;


            try {
                a[11] = 22;
            }catch(ArrayIndexOutOfBoundsException aoe){
                aoe.printStackTrace();
                System.out.println("aoe excepiton");
            }
            catch(ArithmeticException ae){
                ae.printStackTrace();
                System.out.println("ae exception");
            }
            catch(Exception e){
                e.printStackTrace();
                System.out.println("Exception is occures");
            }finally {
                //terminated
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }


        System.out.println(a[10]);

            try{
                System.out.println("closing all objects");
            }finally {
                try {
                    if(br !=null)
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

    }//main en
}//class
