package com.nt.exceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionOneDemo {

    public static void main(String[] args) {

        // Scanner sc=null;

          //      sc=new Scanner(System.in);
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("enter the multi word::");
        //String sw=sc.nextLine();
        try {
            String sw=br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("enter string value::");
       // String name=sc.next();
        try {
            String name=br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("enter the integer::");
        int no=0;

           //  no = sc.nextInt();
            try {
                 no=Integer.parseInt(br.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }        catch(InputMismatchException ime){
            ime.printStackTrace();
            System.out.println("exception");
        }
        System.out.println("enter the float value::");

            //float f=sc.nextFloat();
            try {
                float f=Float.parseFloat(br.readLine());
                    throw new IOException("Excepiton data");
            } catch (IOException e) {
                e.printStackTrace();
            }
           catch(InputMismatchException ime){
            ime.printStackTrace();
            System.out.println("exception");
        }

        System.out.println("enter the double value");
       // double d=sc.nextDouble();
        System.out.println("enter the byte value::");
       // byte b=sc.nextByte();
        //System.out.println("b :: "+b);
    }
}
