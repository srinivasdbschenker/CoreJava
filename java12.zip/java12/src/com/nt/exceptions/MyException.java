package com.nt.exceptions;

import jdk.nashorn.internal.runtime.ECMAException;

public class MyException extends  Exception {
    private  static int accno[]={1001,1002,1003,1004,1005};
    private static String name[]={"subbarao", "apparao","venkatarao","valeswarao","srinivasarao"};
    private static double bal[]={1000, 12000,50, 25000, 100000};

    MyException(){

    }

    MyException(String str){
        super(str);
    }

    public static void main(String[] args) {
       try{
            System.out.println("accno"+"\t"+"name"+"\t"+"bal");
            for(int i=0; i<5;i++){


                    System.out.println(accno[i]+"\t"+name[i]+"\t"+bal[i]);
               if(bal[i]<500){

//
                          MyException me = new MyException("Balance amount is less than 500 please maintain above 500");
                        throw me;

                    //throw new Exception("balance amount is 500");
                }//if

            }//for
        }catch (MyException me){
           me.printStackTrace();
        }
        catch(Exception e){
           e.printStackTrace();
       }
    }
}
