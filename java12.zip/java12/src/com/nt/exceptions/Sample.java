package com.nt.exceptions;

import java.io.IOException;

public class Sample {
    static void demo(){
        try{
            System.out.println("inside demo():: ");
            int bal=5000;
            throw new NullPointerException(" data should not be a blank");

        }catch(NullPointerException ne){
            ne.printStackTrace();

        }
    }
}
