package com.nt.exceptions;

public class SampleDemo {
    public static void main(String[] args) {
        Sample.demo();

    }
}
