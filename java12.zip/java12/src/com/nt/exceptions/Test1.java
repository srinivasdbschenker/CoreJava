package com.nt.exceptions;

public class Test1 {
    public static void main(String[] args) {
        throw new ArithmeticException("/by zero do't use devide by zero");

        //throw e; e-> any throwable object
    }
}
