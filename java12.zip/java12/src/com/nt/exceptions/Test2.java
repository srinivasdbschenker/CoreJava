package com.nt.exceptions;

public class Test2 extends Exception {
    public static void main(String[] args)  {
        try {
            throw new Test2();
        } catch (Test2 test2) {
            test2.printStackTrace();
        }
    }
}
