package com.nt.exceptions;

public class Test3 extends  RuntimeException {
    public static void main(String[] args) {
        throw new Test3();

    }
}
