package com.nt.exceptions;

public class Test4 {
    static int a;
//static   ArithmeticException e=new ArithmeticException();
    static ArithmeticException e;
    public static void main(String[] args) {
        //throw e;
        a=10;

    }
}
