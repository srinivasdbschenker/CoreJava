package com.nt.exceptions;

public class Test5 {
    public static void main(String[] args) {

        if(false) {
            System.out.println("after throw statment....!");
            throw new ArithmeticException("hi");

           // System.out.println("after throw statment....!");
        }else {
            System.out.println("after throw statment....!");
        }


    }
}
