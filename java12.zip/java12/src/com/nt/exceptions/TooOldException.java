package com.nt.exceptions;

public class TooOldException  extends  RuntimeException{
    TooOldException(String s){
        super(s);
    }
}
