package com.nt.exceptions;

public class TooYoungException  extends RuntimeException{

    TooYoungException(String s){
        super(s);
    }
}
