package com.nt.files;

import java.io.*;

public class CreateFile2 {
    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub


        DataInputStream dis=new DataInputStream(System.in);

        FileOutputStream fout=new FileOutputStream("myfile1.txt");


        BufferedOutputStream bout=new BufferedOutputStream(fout, 1024);

        System.out.println("enter char @");

        char ch;
        try {
            while((ch=(char) dis.read()) != '@')
                bout.write(ch);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        bout.close();

    }

}
