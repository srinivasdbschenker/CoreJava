package com.nt.files;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFileDemo {

    public static void main(String[] args) throws IOException, FileNotFoundException {
        // TODO Auto-generated method stub

        String s="this is book on java: "+"\n i am a learner of core java "+"\n i am future java programmer and expert in java/j2ee";

        FileWriter fw=new FileWriter("Text");

        for(int i=0; i<s.length();i++)
            fw.write(s.charAt(i));

        fw.close();

        System.out.println("-------------------------------");

        int ch;
        FileReader fr=null;

        fr=new FileReader("Text");

        while((ch=fr.read()) != -1)
            System.out.print((char)ch);

        fr.close();

    }

}
