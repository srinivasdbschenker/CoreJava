package com.nt.files;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterOutputStream;

public class Unzip {
    public static void main(String[] args)throws Exception{

//attach the original file:file1 to FileInputStream for reading data

        FileInputStream fis=new FileInputStream("fzip");

//attach compressed file:file2 to FileOutputStream

        FileOutputStream fos=new FileOutputStream("fzip1");

//attach FileOutputStrea to DeflaterOutptuStream

//        DeflaterOutputStream dos=new DeflaterOutputStream(fos);
        InflaterOutputStream dos=new InflaterOutputStream(fos);

//read data from FileInputStream and write it into DeflaterOutputStream

        int data;
        while((data = fis.read()) != -1)
            dos.write(data);

        fis.close();
        dos.close();
    }



}
