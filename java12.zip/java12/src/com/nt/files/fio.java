package com.nt.files;

import java.io.IOException;
import java.io.OutputStream;

public class fio {
    public static void main(String[] args) throws IOException {

        String s = "Hello world";
        //OutputStream out = ftp.uploadStream("Hello.txt");
        try {
            //out.write(s.getBytes());
        }
        finally {
           // out.close();
        }
    }
}
