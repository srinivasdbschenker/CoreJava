package com.nt.inheritances;

public class Employee extends Person {

    int p;
    double r;
    double t;
    double si;
   int age=2;

    public void data(){
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);

        System.out.println("super age:: "+super.age);
    }

     void data(int a){
       age=a;
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);
         System.out.println("super age:: "+super.age);

     }

    public void data(int a, int name){
        age=a;
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);
        Employee e=new Employee();
        e.data(10);
    }


    public void si(){
        System.out.println("the simple interest :: ");
        si=(p*t*r)/100;
        System.out.println("the si:: "+si);
    }
}
