package com.nt.inheritances;

public class PerEmpDemo {
    public static void main(String[] args) {
        Person p=new Person();
        p.age=10;
        p.name="raja";
        p.data();
        p.data(12);

        System.out.println("-----");
        Employee e=new Employee();
        e.data();
        e.p=100000;
        e.r=2;
        e.t=20;
        e.si();
        e.age=12;
        e.name="rani";
        e.data();
     e.data(13);

    }
}
