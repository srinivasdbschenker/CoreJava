package com.nt.inheritances;

public class Person {
    int age=22;
    String name;

    public void data(){
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);

    }

     void data(int a){
        age=a;
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);
    }


}
