package com.nt.inheritances;

public class Student extends Teacher{
    /*int age;

    String name;
    char gen;
*/
    float marks;

    public int getAge() {
        System.out.println("sub");
        return age;
    }

    public void setAge(int age) {
        System.out.println("sub class");
        this.age = age;
    }
/*
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getGen() {
        return gen;
    }

    public void setGen(char gen) {
        this.gen = gen;
    }
*/
    public float getMarks() {
        return marks;
    }

    public void setMarks(float marks) {
        this.marks = marks;
    }

}
