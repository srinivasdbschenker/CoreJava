package com.nt.inheritances;

public class Teacher  {


    int age;
    String name;
    char gen;
    float sal;

    public int getAge() {

        System.out.println("super");
        return age;
    }

    public void setAge(int age) {
        System.out.println("super");
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getGen() {
        return gen;
    }

    public void setGen(char gen) {
        this.gen = gen;
    }

    public float getSal() {
        return sal;
    }

    public void setSal(float sal) {
        this.sal = sal;
    }

    //setters and getters

}
