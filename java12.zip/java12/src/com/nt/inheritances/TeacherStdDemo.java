package com.nt.inheritances;

public class TeacherStdDemo {
    public static void main(String[] args) {
        Teacher t=new Teacher();
        t.setAge(20);
        t.setName("rani");
        t.setGen('f');
        t.setSal(20000.25f);

        System.out.println(" Teacher age ::"+t.getAge()+ " \t name:: "+t.getName()+" \t gen:: "+t.getGen()+" \t Sal "+t.getSal());

        Student s=new Student();
        s.setAge(17);
        s.setName("raja");
        s.setGen('m');
        s.setMarks(550.6f);
        System.out.println("student age:: "+s.getAge()+" \t name:: "+s.getName()+" \t gen:: "+s.getGen()+" \t Marks:: "+s.getMarks());

         int x=10;
         double y=x;//10.0
         int z= (int) y;//10

        Teacher t1=new Student();//only super properties
        System.out.println("sub classsssssssssss");
        t1.setAge(12);
        System.out.println(t1.getAge());

        //Student s1= (Student) new Teacher();
        //s1.getSal();



    }
}
