package com.nt.input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DifferentInputTokenizer {
    public static void main(String[] args)  {

        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
String str;
        str = null;
        System.out.println("enter the input");
        try {
             str = br.readLine(); //raja
        }catch(IOException ie){
            ie.printStackTrace();
        }catch(ArithmeticException aie){
            aie.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        StringTokenizer st=new StringTokenizer(str,","); // raja , 123 , m , hyderabad

        String s1=st.nextToken();
        String s2=st.nextToken();
        String s3=st.nextToken();
        String s4=st.nextToken();
        s1=s1.trim();
        s2=s2.trim();
        s3=s3.trim();
        s4=s4.trim();

        String name=s1;
        int no=0;
        try {
             no = Integer.parseInt(s2);
        }catch(Exception e){
            e.printStackTrace();
        }
        String gen=s3;
        String place=s4;

        System.out.println("name:: "+name);
        System.out.println("no:: "+no);
        System.out.println("gen:: "+gen);
        System.out.println("place:: "+place);




    }
}
