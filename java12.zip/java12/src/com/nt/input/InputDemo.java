package com.nt.input;

import java.io.BufferedReader;  //alt + enter--intilij
import java.io.IOException;        //ctrl+shift+o --> eclipse
import java.io.InputStreamReader;
import java.sql.SQLOutput;

public class InputDemo {

    public static void main(String[] args) throws IOException {
        System.out.println("Input Demo");

      //  InputStreamReader ins=new InputStreamReader(System.in);
        //BufferedReader br=new BufferedReader(ins);
        //or\
try {
    int[] a = new int[-1];
    System.out.println("a:: " + a.length);
}catch (NegativeArraySizeException ne){
    ne.printStackTrace();
}
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Read String value");
        String name=br.readLine();
        System.out.println("name :: "+name);
        System.out.printf("name :: %s ",name);

        System.out.println("enter integer value");
        int i=Integer.parseInt(br.readLine());//1 2 3 "Rani" "124" "23.56"

        System.out.println("integer value i:: "+i);

        System.out.printf("integer value i::%d ",i);
        System.out.println("enter double value");
        double d=Double.parseDouble(br.readLine());
        System.out.println("the double value :: "+d);
        System.out.printf("the double value :: %f",d);

        System.out.println("enter long value :: ");
        long l=Long.parseLong(br.readLine());
        System.out.println("the long value is ::"+l);
        System.out.println("enter byte value::");
        byte b=Byte.parseByte(br.readLine());
        System.out.println("the byte value :: "+b);
        System.out.println("enter short value :: ");
        short s=Short.parseShort(br.readLine());
        System.out.println("the short value :: "+s);
        System.out.println("enter float" +
                "");
        float f=Float.parseFloat(br.readLine());
        System.out.println("enter boolean");
        boolean b1=Boolean.parseBoolean(br.readLine());
        System.out.println("boolean value :: "+b1);


        System.out.println("ente char value using read()");
        char c= (char) br.read(); // A  65  a --97  B -- 66

        System.out.println("the char value :: "+c);
            br.skip(0);
        System.out.println("enter char CharAt(2) ");
        char ch=br.readLine().charAt(2);  //Raja

        System.out.println("the char value is :: "+ch);
        System.out.printf("the char value is :: %c ",ch);






    }
}
