package com.nt.input;

import java.util.Scanner;

public class ScannerDemo {
     void sum(){
        System.out.println("hi");
    }

    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in); //token  --1010

        System.out.println("enter mulit word ");
        String sw=sc.nextLine();
        System.out.println("enter integer value:: ");
        int no=sc.nextInt();

        System.out.println("enter string value");
        String name=sc.next();
        System.out.println("enter float value:: ");
        float nof=sc.nextFloat();
        System.out.println("enter double value:: ");
        double d=sc.nextDouble();

        System.out.println("enter long value:: ");
        long l=sc.nextLong();
        System.out.println("enter byte value ");
        byte b=sc.nextByte();
        System.out.println("enter boolean value ");
        boolean bl=sc.nextBoolean();
        System.out.println("ente char value ");
        String s=sc.next();
        char ch=s.charAt(1);


        System.out.println("enter short:: ");
        short st=sc.nextShort();


    }
}
