package com.nt.interfaces;

public  class EpsonPrinter implements Printer{


	@Override
	public void printit(String text) {
		// TODO Auto-generated method stub
		System.out.println("Epson");
		System.out.println(text);

	}

	@Override
	public void disonnect() {
		// TODO Auto-generated method stub

		System.out.println("printing completed");
		System.out.println("disconnect from EPson printer");
	}

}
