package com.nt.interfaces;

public class IBMPrinter  implements Printer{


	@Override
	public void printit(String text) {
		// TODO Auto-generated method stub
		System.out.println("ibm");
		System.out.println(text);

	}

	@Override
	public void disonnect() {
		// TODO Auto-generated method stub

		System.out.println("Printing completed");
		System.out.println("Disconected from IBM Printer");

	}

}
