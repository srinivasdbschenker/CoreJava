package com.nt.interfaces;

public interface InterfaceDemo {


	void connect();  //public and abstract
	void disconnect();


	

}
