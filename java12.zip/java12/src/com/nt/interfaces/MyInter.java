package com.nt.interfaces;

public interface MyInter {

	int a=10;

	void sum();
	void sub();


}
