package com.nt.interfaces;

public class MyInterfaceDemo {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub



		//Class c=Class.forName(args[0]);
		
		//InterfaceDemo id=(InterfaceDemo) c.newInstance();

		//OracleDB id=new OracleDB();
		 //jar---java archive
		//war--> web archive
		//ear--> enterprise archive
//SOAP
		//REST

		//--> new --> class presence should in current workspace

		Class c=Class.forName("com.nt.interfaces.OracleDB");
		InterfaceDemo id= (InterfaceDemo) c.newInstance();

		InterfaceDemo id3=new OracleDB();

		id.connect();
		id.disconnect();

		Class c1=Class.forName("com.nt.interfaces.SybaseDB");
		InterfaceDemo id1= (InterfaceDemo) c1.newInstance();

		id1.connect();
		id1.disconnect();

		OracleDB od=new OracleDB();
		od.connect();
		od.disconnect();





	}

}
