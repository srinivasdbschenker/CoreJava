package com.nt.interfaces;

public class OracleDB implements InterfaceDemo {



	@Override
	public void connect() {
		 //loadd
		//connect drivermanager
		//create statment  10
		System.out.println("Oracle DB is conected");
	}

	@Override
	public void disconnect() {
		System.out.println("oracle DB is disconnected");

	}
}
