package com.nt.interfaces;

public interface Printer {


	void printit(String text);
	void disonnect();
	
}
