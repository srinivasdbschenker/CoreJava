package com.nt.interfaces;

public class SybaseDB implements InterfaceDemo{


	@Override
	public void connect() {
		// TODO Auto-generated method stub
		System.out.println("connecting sybase data base");
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		System.out.println("disconnected sybase data base");
		
	}

}
