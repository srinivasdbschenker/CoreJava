package com.nt.lambdaexpressions;


public class LamdaDameo1 {
	

	interface MyInter{
		
		void message();
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hi i am first");
		MyInter mi=()->{System.out.println("Hello how r u");};
		
mi.message();
	}

}
