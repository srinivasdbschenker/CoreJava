package com.nt.lambdaexpressions;

public class LamdaDemo2 {
	
	interface MyInter{
		void add(int a, int b);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyInter mi =(int a, int b)->{System.out.println("sum :: "+(a+b));};
	
	mi.add(22, 11);
	}

}
