package com.nt.lambdaexpressions;

public class LamdaDemo3 {
	
	interface MyInter{
		double squareroot(double num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyInter mi=(double x)->{return Math.sqrt(x);};

		//double x=mi.squareroot(25);
		//System.out.println("x:: "+x);
		System.out.println("sqaure root :: "+mi.squareroot(256));

	}

}
