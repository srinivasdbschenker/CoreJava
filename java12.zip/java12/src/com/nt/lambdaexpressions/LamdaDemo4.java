package com.nt.lambdaexpressions;

public class LamdaDemo4 {
	int x=10;
	
	void method(){
		int x=20;
		
	
		Runnable r=()->{System.out.println("var of the class= "+this.x);};

		System.out.println("var of the metod : "+x);
		Thread t=new Thread(r);
		t.start();
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LamdaDemo4 obj=new LamdaDemo4();
		obj.method();
	}

}
