package com.nt.objectcreation;

public class MySql {
    public void connect(){
        System.out.println("MySql is connected");
    }
    public void disconnect(){
        System.out.println("MySql is disconnected");
    }
}
