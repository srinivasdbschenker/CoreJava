package com.nt.objectcreation;

public class Oracle {

    public void connect(){
        System.out.println("Oracle is connected");
    }
    public void disconnect(){
        System.out.println("Oracle is disconnected");
    }
}
