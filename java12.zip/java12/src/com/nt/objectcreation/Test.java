package com.nt.objectcreation;

public class Test {
    static{
        System.out.println("Test static block");
    }

    int a;
    float b;

    public Test(int a) {
        this.a = a;
    }

    @Override
    public String toString() {
        return "Test{" +
                "a=" + a +
                ", b=" + b +
                '}';
    }

    Test(){
        System.out.println("test o argument constructor");
    }

    public Test(int a, float b) {
        this.a = a;
        this.b = b;
    }
}
