package com.nt.objectcreation;

import com.nt.threads.MyThread;

public class TestDemo {
    static{
        System.out.println("TestDemo static blocks");
    }
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        System.out.println("main starting");
           Test t=new Test();

        Test t1=new Test();

        //by using static factory method
     //a method in a java class is capable of constructing and returning it own java class object is called as static factory method
     //as static factory method

        String s1=String.valueOf(10);
        System.out.println("s1:: "+s1+ "address:: "+s1.hashCode());

        Thread t3=Thread.currentThread();
        System.out.println(t3);

        //by using instance factory method
        String s=new String("Hello");
        String s2=s.concat("how are you");

        System.out.println("s2 :: "+s2);

        //static methods are called without object. instance methods are called with object

        /**
         * 3.Using newInstance() method
         *
         *   1. First, store the class name "Employee" as a string into an object. using forName()
         *
         *            Classs  c=Class.forName("Employee");
         *     2. create another object to the class whose name is in the object c
         *              Employee obj=c.newInstance();
         */

        Class c=Class.forName("com.nt.objectcreation.Oracle");
        Oracle o= (Oracle) c.newInstance();
        o.connect();
        o.disconnect();

        Class c1=Class.forName("com.nt.objectcreation.MySql");
        MySql m= (MySql) c1.newInstance();
        m.connect();
        m.disconnect();




        System.out.println("main is ended ");
    }
}
