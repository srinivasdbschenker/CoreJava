package com.nt.oops;

public class Employee {
    String age, name, gen;

    Employee(String a, String n, String g){
        this.age=a;
        this.name=n;
        this.gen=g;
    }


}
