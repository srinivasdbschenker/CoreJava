package com.nt.oops;

public class EmployeeCheck {

    public void check(Employee obj){
        System.out.println("age :: "+obj.age+" name :: "+obj.name+" gen :: "+obj.gen);

        String temp;
        temp=obj.age;
        obj.age=obj.name;
        obj.name=obj.gen;
        obj.gen=temp;

        System.out.println("age :: "+obj.age+" name :: "+obj.name+" gen :: "+obj.gen);

    }

    public void check(Object obj){

    }
}
