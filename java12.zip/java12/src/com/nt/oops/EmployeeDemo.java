package com.nt.oops;

public class EmployeeDemo {

    public static void main(String[] args) {

        Employee e=new Employee("10","raja","male");
        System.out.println(" main :: age :: "+e.age+" name :: "+e.name+" gen :: "+e.gen);

        EmployeeCheck ec=new EmployeeCheck();
        ec.check(e);

        System.out.println("main :: age :: "+e.age+" name :: "+e.name+" gen :: "+e.gen);




    }
}
