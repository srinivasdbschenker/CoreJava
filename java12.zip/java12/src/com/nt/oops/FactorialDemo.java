package com.nt.oops;

import java.util.Date;

public class FactorialDemo {

    static long factorial(int num){
        long result;

        if(num==1) return 1;
        result=factorial(num-1)*num;                    // f(4)*5  f(3)*20 f(2) *60 f(1)*120 120



        return result;
    }

    public static void main(String[] args) {

        Date d=new Date();
        System.out.println(" d: "+d);

        System.out.println(FactorialDemo.factorial(5));


        //5!  =5 * 4 * 3 * 2 *1  =120
         // 5*4!
        // 5*4*3!
         //20*3*2!
        // 60*2*1!
        //120
        int fact=1,f=1;
        int n=5;

        for(int i=5;i>0;i--){
            fact=fact*i; //1*5 5*4 20 20*3  60*2 120
            }
        System.out.println(fact);

        for(int j=1; j<=n;j++){
            f=f*j; //1*1 1 1*2 2 2*3 6 24 120
        }
        System.out.println("f ::"+f);


    }
}
