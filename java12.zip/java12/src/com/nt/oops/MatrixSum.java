package com.nt.oops;

import java.io.IOException;

public class MatrixSum {


    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        // 2*4 4*2   2*2
        Matrix obj1=new Matrix(3,3);
        Matrix obj2=new Matrix(3,3);

        int x[][],y[][],z[][];

        System.out.println("\n eneter elements for first Matrix:: ");
        x=obj1.getMatrix();

        System.out.println("\n enter elemetns for second matrix:: ");
        y=obj2.getMatrix();

        z=obj1.findSum(x, y);
        System.out.println("the matrix sum is :: ");

        obj2.displayMatrix(z);
    }


}
