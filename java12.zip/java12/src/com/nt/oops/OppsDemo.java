package com.nt.oops;

public class OppsDemo {

    private  void sum(){
        System.out.println("sum method");
        OppsDiff opdf=new OppsDiff();
        System.out.println(opdf.mul());

    }

    public static void main(String[] args) {
        System.out.println("hi How are you");
        //classname objectname=new classname();

        OppsDemo od=new OppsDemo();

        od.sum();

        OppsDiff odf=new OppsDiff();
        //System.out.println( odf.mul());


        int a=odf.mul();
        System.out.println("return value ::a :: "+a);
        odf.mul();
        odf.multi();


    }

            }

