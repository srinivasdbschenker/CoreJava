package com.nt.oops;


class OppsDiff {
    //modifier returntype methodname(parameterlist){--} // public private protected modifier

     void sub(){
        int a=10;
        int b=20;
        System.out.println("b-a:: "+(b-a));


     }
     int mul(){
        int a=10*5;
        System.out.println("12*3::"+(112*3));
        return a;

    }

    int multi(){
        int a=10*5;
        System.out.println("12*3::"+(112*3));
        return a;

    }
}
