package com.nt.oops;

public class PassObj {

    public void sum(Object obj){
        System.out.println("object values :: "+obj);

        System.out.println("object values to String :: "+obj.toString());


        System.out.println("object values hash code :: "+obj.hashCode());

        System.out.println("object values get class :: "+obj.getClass());
    }
}
