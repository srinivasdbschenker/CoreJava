package com.nt.oops;

public class PassObjDemo {

    int x;
    int y;
    public static void main(String[] args) {

         int x=10;

        PassObjDemo pd=new PassObjDemo();
        pd.x=20;
        pd.y=50;

        System.out.println(" x :: "+pd.x+" y:: "+pd.y);

        PassObj po=new PassObj();
        po.sum(pd);
    }
}
