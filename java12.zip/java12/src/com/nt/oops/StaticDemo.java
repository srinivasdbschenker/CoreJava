package com.nt.oops;

public class StaticDemo {

    //classlevel  blocklevel methodlevel variablelevel
    static{
        System.out.println("static block of static demo");
    }
    StaticDemo(){
        System.out.println("StaticDemo() constructor");
    }

}
