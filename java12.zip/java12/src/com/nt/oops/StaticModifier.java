package com.nt.oops;

public class StaticModifier {
    static int p,q;

    int a, b;
static{
    System.out.println("static block");
}
    StaticModifier(){
        System.out.println("StaticModifier constructor");
        a=10;
        b=20;
    }

    public StaticModifier(int i) {
    a=i;
    }

    public static void  sum(){
        System.out.println("sum");
        int s,r;

    }

    public  void  sum1(int w, int t){
      int z=w+t;
        System.out.println("sum"+z);
    }
    public static void main(String[] args) {
    int x=22, y=33;
        StaticModifier.p=13;
        StaticModifier.q=14;


        System.out.println("main() started ");
        StaticModifier.sum();

        StaticModifier sm=new StaticModifier();
      sm.sum1(x,y);
      sm.sum1(20,20);
        sm.a=20;

        StaticModifier sm1=new StaticModifier();

        StaticModifier sm2=new StaticModifier(12);

         sm.sum();
        StaticDemo sd=new StaticDemo();

        System.out.println("main() ended");

    }
    static{
        System.out.println("static block");
    }
    static{
        System.out.println("static block");
    }
}
