package com.nt.oops;

public class StaticOne {

    int p;

    public int sum(int x, int y){

        System.out.println("x :: "+x+" y:: "+y);
        int z;
        this.p=20;
        z=x;
        x=y;
        y=z;
        System.out.println("x :: "+x+" y:: "+y);
        return 100;

    }
}
