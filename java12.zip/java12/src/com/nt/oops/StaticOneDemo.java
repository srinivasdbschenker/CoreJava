package com.nt.oops;

public class StaticOneDemo {
    public static void main(String[] args) {
        int x=10;
        int y=20;
        System.out.println(" main() x ::" +x+" y:: "+y);

        StaticOne sd=new StaticOne();
        System.out.println( sd.sum(x,y));

        System.out.println(" main() x ::" +x+" y:: "+y);

    }
}
