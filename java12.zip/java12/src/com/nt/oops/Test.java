package com.nt.oops;

public class Test {
    int age;
    String name;

   Test(){
        age=22;
        name="raja";
        System.out.println("Test constructor");
    }

     Test(int i) {
        age=i;
        name="Shalini";
        System.out.println("one parametereized constructor");
    }

     Test(float v) {
    }
//signature{ method body}
    //modifier return type methodname(parameter list){-}

    public void details(){
        System.out.println("age:: "+age);
        System.out.println("name :: "+name);
    }

    public void details(int a){
        System.out.println("age1:: "+a);
        System.out.println("name1 :: "+name);
    }
    public void details(float b){
        System.out.println("age1:: "+b);
        System.out.println("name1 :: "+name);
    }
}
