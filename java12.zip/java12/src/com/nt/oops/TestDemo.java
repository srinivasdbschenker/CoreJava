package com.nt.oops;

public class TestDemo {

    //classname(parameterlist){--}

    TestDemo(){
        System.out.println("TestDemo() constructor");
    }

    public TestDemo(int i) {
        System.out.println("i :: "+i);
    }

    public static void main(String[] args) {

        //TestDemo td=new TestDemo();
        //TestDemo td1=new TestDemo(12);

        Test t=new Test();
       t.age=20;
        t.name="rani";

         t.details();
      t.details(20);
      t.details(21.2f);
         Test t2=new Test();
         t2.details();

         Test t3=new Test(23);
         t3.details();
         t3.details(23.0f);
         t3.details(24);

         Test t4=new Test(25.2f);


    }
}
