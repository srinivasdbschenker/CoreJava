package com.nt.oops;

public class ThisClass {

    int a=10, b,c;

        int x,y,z;
    ThisClass(){
        System.out.println("this is zero parameter class");
        ThisClass t=new ThisClass(10,12,13);


    }

    ThisClass(int x, int y, int z){
         this.x=x;
         y=y; //right thumb rule
         z=z;

        // int x=10;
         //double y=x;
         //y=10.0;
          // this.a=x;  //a=x;
            //this.b=y;  //b=y;
             //this.c =z ; // c=z;
        //System.out.println("a :: "+a);
        //System.out.println("b :: "+b);
        //System.out.println("c :: "+c);
       this.sum();
        //this.sum();
    }

    public void sum(){
        System.out.println("the sum ");
        sum1();
        // performance:  memeory   spead    conflict: exceptions
    }
    static void sum1(){
        System.out.println("the sums ");
    }
}
