package com.nt.oops;

public class ThisDemo {
    static void sum2(){
        System.out.println("the sums ");
    }
    public static void main(String[] args) {
        System.out.println("");
        ThisClass t=new ThisClass();
    }
}
