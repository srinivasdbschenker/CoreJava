package com.nt.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FilterWithStream {

    public static void main(String[] args) {

        List<Product> productList=new ArrayList<Product>();
        productList.add(new Product(1,"HP Laptop", 25000f));

        productList.add(new Product(2,"Dell Lapttop", 300000f));

        productList.add(new Product(3,"Lenovo Laptop", 28000f));

        productList.add(new Product(4,"Sony Laptop", 29000f));

        productList.add(new Product(5,"Apple Laptop", 27000f));
        productList.add(new Product(6,"Thoshiba Laptop", 90000f));

        System.out.println("Product lis t: "+productList);

        List<Float> produceList2=productList.stream()
                                               .filter(p ->p.price < 30000)
                                                .map(p ->p.price)
                                                .collect(Collectors.toList());
        System.out.println(produceList2);

    }
}
