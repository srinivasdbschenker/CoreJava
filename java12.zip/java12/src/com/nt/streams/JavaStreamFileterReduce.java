package com.nt.streams;

import java.util.ArrayList;
import java.util.List;

public class JavaStreamFileterReduce {
    public static void main(String[] args) {

        List<Product> productList=new ArrayList<Product>();
        productList.add(new Product(1,"HP Laptop", 25000f));

        productList.add(new Product(2,"Dell Lapttop", 300000f));

        productList.add(new Product(3,"Lenovo Laptop", 28000f));

        productList.add(new Product(4,"Sony Laptop", 29000f));

        productList.add(new Product(5,"Apple Laptop", 27000f));
        productList.add(new Product(6,"Thoshiba Laptop", 90000f));

        System.out.println("Product lis t: "+productList);

        //This is more compact approach for filetering data

        Float totalPrice=productList.stream().map(product->product.price).reduce(0.0f,(sum,price)->sum+price);
        System.out.println(totalPrice);

        float totalPrice2=productList.stream().map(product->product.price).reduce(0.0f,Float::sum);
        System.out.println(totalPrice2);
    }
}
