package com.nt.strings;

public class StringBufferDemo {
    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("HI how are you");
        System.out.println("sb :: "+sb+"   sb :: address -->"+sb.hashCode());
        //sb.append("welcome to java");
        System.out.println("sb :: "+sb+"   sb :: address -->"+sb.hashCode());

        StringBuffer sb1=new StringBuffer("HI how are you");
        System.out.println("sb1 address "+sb1.hashCode());

        if(sb==sb1){
            System.out.println("sb and sb1 are equal ==");
        }else{
            System.out.println("sb and sb1 are not eqaul ==");
        }

        System.out.println("-----------");

        if(sb.equals(sb1)){
            System.out.println("sb and sb1 are equals");
        }else{
            System.out.println("sb and sb1 are not eqauls");
        }

        StringBuilder sbd=new StringBuilder("HI How are you");
        System.out.println("sbd:: "+sbd+ " sbd address :: "+sbd.hashCode());

    }
}
