package com.nt.strings;

public class StringDemo {
    public static void main(String[] args) {

        int i=0;
        System.out.println(i);
        i=1;
        System.out.println(i);
        String s="raja";
        System.out.println("s:: "+s+"  address "+s.hashCode());
        s="rani";
        System.out.println("s:: "+s+"  address "+s.hashCode());

        //classname objname=new classname();

        String s1=new String("hello");
        System.out.println("s1:: "+s1+" s1 address :: "+s1.hashCode());
        s1="How are you";
       // s1="";
        System.out.println("s1:: "+s1+" s1 address :: "+s1.hashCode());

        char arr[]={'c','h','a','i','r','s'};

        String s2=new String(arr);
        System.out.println("s2:: "+s2+" address of s2:: "+s2.hashCode());

        System.out.println("concat :: "+s1.concat(s2));

        System.out.println("index "+s1.indexOf('u'));
        System.out.println(s1.isEmpty());
        s1="raja"; //97
        s2="rajz rani";//97+26 123
        System.out.println(s1.compareTo(s2));
        //a=65 a=97
        System.out.println(s2.compareTo(s1));
        //System.out.println(s1.);
    }
}
