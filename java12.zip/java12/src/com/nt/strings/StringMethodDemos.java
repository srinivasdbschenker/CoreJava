package com.nt.strings;

public class StringMethodDemos {
    public static void main(String[] args) {
        String s="Welcome to java world";
        //String s1="Hi java is oops language";

        String s1="Welcome to java world";


        s1="Welcome to java worlds";
//String s=new String("Welcome to java world");

    //    String s1=new String("Welcome to java world");

        if(s==s1){
            System.out.println("== s and s1 are equal");
        }else{
            System.out.println("== s and s1 are not equal");
        }

        if(s.equals(s1)){
            System.out.println("equals :: s and s1 are equal");
        }else{
            System.out.println("equals:: s and s1 are not equal");
        }

        System.out.println("s "+s.hashCode());
        System.out.println("s1 :: "+s1.hashCode());

    }
}
