package com.nt.threads;

class Cancellation extends Thread{
    public void run(){
        System.out.println("I am cancellation thread");
    }
}
