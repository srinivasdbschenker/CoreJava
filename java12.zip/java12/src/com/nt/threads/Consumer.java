package com.nt.threads;

public class Consumer extends Thread {
	
	Producer prod;


	Consumer(Producer prod){

		this.prod=prod;
	}
	
	public void run(){
		synchronized(prod.sb){
			
			
			try{
				System.out.println("consumer :: "+prod.sb);
				prod.sb.wait();

			}catch(Exception e){}
			
			System.out.println(prod.sb+"consumer");
		}
	}

}
