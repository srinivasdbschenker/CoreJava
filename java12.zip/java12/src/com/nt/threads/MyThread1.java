package com.nt.threads;

public class MyThread1 implements Runnable  {


	@Override
	public void run() {
		// TODO Auto-generated method stub
		task1();
		task2();
		task3();

	}
	
	void task1(){
		System.out.println("this is task1");
	}

	void task2(){
		System.out.println("this is task2");
	}
	void task3(){
		System.out.println("this is task3");
	}

}
