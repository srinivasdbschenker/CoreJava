package com.nt.threads;

public class PriorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass obj=new MyClass();


		Thread t1=new Thread(obj, "one");
		Thread t2=new Thread(obj, "Two");

		t1.setPriority(2);
		//t1.setPriority(Thread.NORM_PRIORITY);
		t2.setPriority(Thread.NORM_PRIORITY); //5
		
		t1.start();
		t2.start();

	}

}
