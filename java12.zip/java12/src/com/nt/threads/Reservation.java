package com.nt.threads;

public class Reservation extends Thread{
    public void run(){
        System.out.println("I am reservation thread");
    }


}
