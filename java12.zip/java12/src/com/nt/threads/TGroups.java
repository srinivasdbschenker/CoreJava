package com.nt.threads;

public class TGroups {
    public static void main(String[] args)throws Exception{

//we should understand that the following statement are executed by the main thread

        Reservation res=new Reservation();
        Cancellation can=new Cancellation();
//Thread t1=new Threa(res,"first thread");

        ThreadGroup tg=new ThreadGroup("First Group");

        Thread t1=new Thread(tg, res, "First thread");
        Thread t2=new Thread(tg, res, "Second thread");

        ThreadGroup tg1=new ThreadGroup(tg, "second Group");

        Thread t3=new Thread(tg1, can ,"Third thread");
        Thread t4=new Thread(tg1, can,"Fourth thread");

        System.out.println("parent of tg1="+tg1.getParent());

        //tg1.setMaxPriority(7);
        //tg.setMaxPriority(4);

        System.out.println("Thread group of t1="+t1.getThreadGroup());
        System.out.println("Thread group of t3="+t3.getThreadGroup());

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        System.out.println("NO of threads active in tg="+tg.activeCount());

    }

}
