package com.nt.threads;

class Tasks implements Runnable {

    private int taskno;

    Tasks(int taskno){
        this.taskno=taskno;

    }

    public void run(){
        for(int i=0; i<=100; i+=25){


            String name=Thread.currentThread().getName();

            System.out.println(name+"completed task" +taskno+"by"+i+"percent");
            try{
                Thread.sleep(3000);
            }catch(InterruptedException ie){}

        }
    }

}
