package com.nt.threads;

import java.util.concurrent.*;


public class ThreadPoolDemo {

    public static void main(String[] args) {


//fixed thread pool is created with 2 threads

        ExecutorService  es= Executors.newFixedThreadPool(40);


//number of tasks are 4 create tasks type array with size 4 t[0] to t[3] represent the four tasks

        Tasks t[]=new Tasks[4];// download 4 thread 4 1

        for(int i=0; i<4; i++){

//attach tasks to the array reference

            t[i]= new Tasks(i);

            es.execute (t[i]);

        }
        es.shutdown();

    }
}
